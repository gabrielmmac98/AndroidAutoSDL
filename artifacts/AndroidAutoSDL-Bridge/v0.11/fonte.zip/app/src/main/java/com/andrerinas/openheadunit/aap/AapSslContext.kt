package com.andrerinas.openheadunit.aap

import android.os.SystemClock
import com.andrerinas.openheadunit.aap.protocol.messages.Messages
import com.andrerinas.openheadunit.connection.projection.ProjectionConnection
import com.andrerinas.openheadunit.ssl.ConscryptInitializer
import com.andrerinas.openheadunit.ssl.NoCheckTrustManager
import com.andrerinas.openheadunit.ssl.SingleKeyKeyManager
import com.andrerinas.openheadunit.utils.AppLog
import com.andrerinas.openheadunit.utils.AuditReportPolicy
import java.nio.ByteBuffer
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLEngine
import javax.net.ssl.SSLEngineResult

class AapSslContext internal constructor(private val sslContext: SSLContext): AapSsl {
    constructor(keyManager: SingleKeyKeyManager) : this(createSslContext(keyManager))

    /** Share resumption caches, not mutable engines, buffers or control queues between links. */
    internal fun newSession(): AapSslContext = AapSslContext(sslContext)
    private lateinit var sslEngine: SSLEngine
    private lateinit var txBuffer: ByteBuffer
    private lateinit var rxBuffer: ByteBuffer
    private lateinit var applicationPump: TlsApplicationPump
    private val controlRecords = java.util.ArrayDeque<ByteArray>()
    private var controlRecordBytes = 0
    @Volatile private var controlRecordListener: (() -> Unit)? = null

    @Volatile var isUserDisconnect = false
    @Volatile internal var onPeerClose: (() -> Unit)? = null

    override fun performHandshake(connection: ProjectionConnection): Boolean {
        if (prepare() < 0) return false

        // Buffer for unencrypted TLS records extracted from AAP messages.
        // We use a local queue or buffer to keep track of bytes ready for the SSLEngine.
        var pendingTlsData = ByteArray(0)
        val frames = HandshakeFrameReader(SystemClock::elapsedRealtime,
            if (connection.type == ProjectionConnection.Type.USB) 100 else 1) { bytes, length, timeout ->
            connection.recvBlocking(bytes, length, timeout, false)
        }

        // Give a slow dongle the whole 15 s TLS phase, including an initially silent peer.
        // A quiet first 2 s is not a separate failure; partial frames and TLS records share
        // this deadline without renewing it. A transport error still stops the read early.
        val deadline = android.os.SystemClock.elapsedRealtime() + SSL_HANDSHAKE_TIMEOUT_MS

        while (getHandshakeStatus() != SSLEngineResult.HandshakeStatus.FINISHED &&
                getHandshakeStatus() != SSLEngineResult.HandshakeStatus.NOT_HANDSHAKING) {

            if (android.os.SystemClock.elapsedRealtime() >= deadline) {
                AppLog.e("SSL Handshake: Timed out after ${SSL_HANDSHAKE_TIMEOUT_MS}ms")
                return false
            }

            when (getHandshakeStatus()) {
                SSLEngineResult.HandshakeStatus.NEED_UNWRAP -> {
                    // If we don't have enough data for a meaningful unwrap, read a full AAP message
                    if (pendingTlsData.isEmpty()) {
                        val messageData = readAapMessage(frames, deadline) ?: return false
                        pendingTlsData = messageData
                    }

                    rxBuffer.clear()
                    val data = ByteBuffer.wrap(pendingTlsData)
                    val result = sslEngine.unwrap(data, rxBuffer)
                    runDelegatedTasks(result, sslEngine)

                    when (result.status) {
                        SSLEngineResult.Status.OK -> {
                            // Keep any unconsumed bytes (e.g. next TLS record already in the buffer).
                            pendingTlsData = if (data.hasRemaining())
                                ByteArray(data.remaining()).also { data.get(it) }
                            else ByteArray(0)
                        }
                        SSLEngineResult.Status.BUFFER_UNDERFLOW -> {
                            // The current pendingTlsData doesn't contain a full TLS record.
                            // Read another AAP message and append it.
                            val nextMessage = readAapMessage(frames, deadline) ?: return false
                            pendingTlsData += nextMessage
                            AppLog.d("SSL Handshake: buffered ${pendingTlsData.size} B after underflow")
                        }
                        else -> {
                            AppLog.e("SSL Handshake: unwrap failed with status ${result.status}")
                            return false
                        }
                    }
                }

                SSLEngineResult.HandshakeStatus.NEED_WRAP -> {
                    val handshakeData = handshakeRead()
                    val bio = Messages.createRawMessage(0, 3, 3, handshakeData)
                    if (connection.sendBlocking(bio, bio.size, 2000) != bio.size) {
                        AppLog.e("SSL Handshake: Send failed")
                        return false
                    }
                }

                SSLEngineResult.HandshakeStatus.NEED_TASK -> {
                    runDelegatedTasks()
                }

                else -> {
                    AppLog.e("SSL Handshake: Unexpected status ${getHandshakeStatus()}")
                    return false
                }
            }
        }

        val sessionId = sslEngine.session?.id
        if (sessionId != null && sessionId.isNotEmpty()) {
            AppLog.i("SSL handshake complete. Session id: ${android.util.Base64.encodeToString(sessionId, android.util.Base64.NO_WRAP)}")
        } else {
            AppLog.i("SSL handshake complete. No session id (full handshake).")
        }
        return true
    }

    /** Consume complete cleartext envelopes before handing their payload to SSLEngine. */
    private fun readAapMessage(frames: HandshakeFrameReader, deadline: Long): ByteArray? {
        while (SystemClock.elapsedRealtime() < deadline) {
            val frame = frames.readFrame(deadline) ?: return null
            if (HandshakeMessagePolicy.isLateVersionResponse(frame)) {
                // Retried requests can produce extra responses. Skip well-formed responses
                // unless they report -1(STATUS_NO_COMPATIBLE_VERSION), just as before TLS.
                if (AapVersionNegotiation.parse(frame, frame.size)?.accepted != true) {
                    AppLog.e("SSL Handshake: invalid late VERSION_RESPONSE")
                    return null
                }
                AppLog.i("SSL Handshake: discarded a late VERSION_RESPONSE")
                continue
            }
            if (frame[0] != 0.toByte() || frame[4] != 0.toByte() || frame[5] != 3.toByte()) {
                AppLog.e("SSL Handshake: expected channel 0 SSL_HANDSHAKE message")
                return null
            }
            return frame.copyOfRange(6, frame.size)
        }
        AppLog.e("SSL Handshake: receive deadline expired")
        return null
    }

    private fun prepare(): Int {
        // Use a consistent (host, port) key so JSSE's ClientSessionContext can find and reuse
        // the session from the previous connection.  The values are arbitrary — they are never
        // used for DNS resolution; they just serve as the cache lookup key.
        sslEngine = sslContext.createSSLEngine("android-auto", 5277).apply {
            useClientMode = true
            session.also {
                val appBufferMax = it.applicationBufferSize
                val netBufferMax = it.packetBufferSize

                txBuffer = ByteBuffer.allocateDirect(netBufferMax)
                rxBuffer = ByteBuffer.allocateDirect(Messages.DEF_BUFFER_LENGTH.coerceAtLeast(appBufferMax + 50))
                // One plaintext buffer for the whole session, sized to what rxBuffer can hold, which
                // is the ceiling on what a single unwrap can produce. See decrypt() for why it is
                // reused rather than allocated per message.
                plaintextBuffer = ByteArray(rxBuffer.capacity())
            }
        }
        controlRecords.clear()
        controlRecordBytes = 0
        sslEngine.beginHandshake()
        return 0
    }

    override fun postHandshakeReset() {
        applicationPump = TlsApplicationPump(sslEngine)
        // Clear buffers. In this implementation, the buffers are re-created for each wrap/unwrap
        // operation (implicitly by ByteBuffer.wrap), but clearing them ensures no stale data.
        txBuffer.clear()
        rxBuffer.clear()
    }

    override fun release() {
        synchronized(this) {
            controlRecordListener = null
            onPeerClose = null
            controlRecords.clear()
            controlRecordBytes = 0
        }
    }

    private fun getHandshakeStatus(): SSLEngineResult.HandshakeStatus {
        return sslEngine.handshakeStatus
    }

    private fun runDelegatedTasks() {
        if (sslEngine.handshakeStatus === SSLEngineResult.HandshakeStatus.NEED_TASK) {
            var runnable: Runnable? = sslEngine.delegatedTask
            while (runnable != null) {
                runnable.run()
                runnable = sslEngine.delegatedTask
            }
            val hsStatus = sslEngine.handshakeStatus
            if (hsStatus === SSLEngineResult.HandshakeStatus.NEED_TASK) {
                throw Exception("handshake shouldn't need additional tasks")
            }
        }
    }

    private fun handshakeRead(): ByteArray {
        txBuffer.clear()
        val result = sslEngine.wrap(emptyArray(), txBuffer)
        runDelegatedTasks(result, sslEngine)
        val resultBuffer = ByteArray(result.bytesProduced())
        txBuffer.flip()
        txBuffer.get(resultBuffer)
        return resultBuffer
    }

    private fun handshakeWrite(start: Int, length: Int, buffer: ByteArray): Int {
        rxBuffer.clear()
        val receivedHandshakeData = ByteArray(length)
        System.arraycopy(buffer, start, receivedHandshakeData, 0, length)

        val data = ByteBuffer.wrap(receivedHandshakeData)
        while (data.hasRemaining()) {
            val result = sslEngine.unwrap(data, rxBuffer)
            runDelegatedTasks(result, sslEngine)
            // Break on any non-OK status (especially BUFFER_UNDERFLOW on a partial TLS record)
            // to prevent an infinite loop. performHandshake() no longer calls this method for
            // NEED_UNWRAP — it handles fragmented records directly via pendingTlsData.
            if (result.status != SSLEngineResult.Status.OK) break
        }
        return receivedHandshakeData.size
    }

    /**
     * Plaintext of the message currently being handled, reused across messages.
     *
     * This used to be `ByteArray(result.bytesProduced())` per call, and the call is per AAP *message*
     * - so per video *fragment*, not per frame. At 50fps with two or three fragments a frame that is
     * 150-250 short-lived arrays a second, each tens of kilobytes, which is large enough to land in
     * the large-object space. It is the churn behind #839's collector running every five to ten
     * seconds, freeing 84-208 large objects a cycle and once pausing for 1.4 seconds on a unit whose
     * decoder was keeping up the whole time.
     *
     * Reusing it is only safe because every consumer of the returned array finishes with it before
     * the next message is decrypted: the poll thread reads, decrypts, dispatches and returns, all
     * synchronously, and the three paths that could have outlived that all copy first - the video
     * feed queue arraycopies into a pooled frame, the audio path arraycopies into its own pooled
     * chunk, and protobuf parsing copies. Every consumer also bounds its reads by the message's
     * `size` field rather than by `data.size`, which is what makes a buffer larger than the payload
     * safe; that was checked call site by call site, and the one place that did not - the short-payload
     * guard in AapMessageIncoming - is fixed alongside this.
     *
     * If anything is ever added that hands `AapMessage.data` to another thread without copying, this
     * is the field that makes it a corruption bug rather than a slow one.
     */
    private lateinit var plaintextBuffer: ByteArray

    /** Reused wrapper, so the per-message allocation is zero rather than one small object. */
    private val plaintextHolder = ByteArrayWithLimit(ByteArray(0), 0)

    // TLS control records may legitimately produce no application bytes. Keep a bounded
    // warning stream so reporter logs show these intervals without flooding normal traffic.
    private var zeroUnwrapReports = 0
    private var zeroUnwrapLastLogMs = 0L
    private var zeroUnwrapSuppressed = 0

    override fun decrypt(start: Int, length: Int, buffer: ByteArray): ByteArrayWithLimit? {
        // The status line is built under the lock but emitted outside it. encrypt() takes this same
        // monitor, so logging in here put the whole logging pipeline — formatting, the caller-name
        // stack walk, the file writer — between the poll thread and the send thread once per
        // decrypted packet, which at verbose is several times per video frame.
        var statusLine: String? = null
        var zeroProduceLine: String? = null
        val decrypted = synchronized(this) {
            if (!::sslEngine.isInitialized || !::rxBuffer.isInitialized || !::plaintextBuffer.isInitialized) {
                AppLog.w("SSL Decrypt: Not initialized yet")
                return null
            }
            try {
                rxBuffer.clear()
                val encrypted = ByteBuffer.wrap(buffer, start, length)
                applicationPump.unwrap(encrypted, rxBuffer) { record ->
                    if (controlRecordBytes + record.size > TlsApplicationPump.MAX_ENCRYPTED_BODY) {
                        throw javax.net.ssl.SSLException("TLS control output queue exceeded its limit")
                    }
                    controlRecords.addLast(record)
                    controlRecordBytes += record.size
                }
                val produced = rxBuffer.position()
                if (AppLog.LOG_VERBOSE) {
                    statusLine = "SSL Decrypt: produced $produced, consumed ${length - encrypted.remaining()} bytes"
                }
                if (produced == 0 && length > 0) {
                    val now = SystemClock.elapsedRealtime()
                    if (AuditReportPolicy.shouldReport(zeroUnwrapReports, zeroUnwrapLastLogMs, now)) {
                        val suffix = if (zeroUnwrapSuppressed > 0)
                            " (and $zeroUnwrapSuppressed more since the last report)" else ""
                        zeroProduceLine = "SSL Decrypt: no application data after consuming $length bytes$suffix"
                        zeroUnwrapSuppressed = 0
                        zeroUnwrapReports++
                        zeroUnwrapLastLogMs = now
                    } else zeroUnwrapSuppressed++
                }
                if (produced > plaintextBuffer.size) {
                    // Cannot happen: rxBuffer is what unwrap writes into and plaintextBuffer is its
                    // capacity. Checked anyway, because silently truncating a message here would look
                    // exactly like stream corruption further down.
                    AppLog.e("SSL Decrypt: produced $produced bytes, larger than the ${plaintextBuffer.size}-byte plaintext buffer")
                    plaintextBuffer = ByteArray(produced)
                }
                rxBuffer.flip()
                rxBuffer.get(plaintextBuffer, 0, produced)
                plaintextHolder.data = plaintextBuffer
                plaintextHolder.limit = produced
                plaintextHolder
            } catch (e: Exception) {
                // Check for Magic Garbage disconnect signal from Wireless Helper
                if (length >= 16) {
                    var allFF = true
                    for (i in 0 until 16) {
                        if (buffer[start + i] != 0xFF.toByte()) {
                            allFF = false
                            break
                        }
                    }
                    if (allFF) {
                        isUserDisconnect = true
                        // Report at recognition, before diagnostics can yield to a failing writer.
                        onPeerClose?.invoke()
                        AppLog.i("SSL Decrypt: Magic Garbage detected. Marking as clean user disconnect.")
                    }
                }

                if (!isUserDisconnect) {
                    AppLog.e("SSL Decrypt failed", e)
                    throw javax.net.ssl.SSLException("TLS application input failed", e)
                }
                null
            }
        }
        statusLine?.let { AppLog.d(it) }
        zeroProduceLine?.let { AppLog.w(it) }
        if (decrypted != null && synchronized(this) { controlRecords.isNotEmpty() }) {
            controlRecordListener?.invoke()
        }
        return decrypted
    }

    override fun encrypt(offset: Int, length: Int, buffer: ByteArray): ByteArrayWithLimit? {
        synchronized(this) {
            if (!::sslEngine.isInitialized || !::txBuffer.isInitialized) {
                AppLog.w("SSL Encrypt: Not initialized yet")
                return null
            }
            try {
                val encrypted = applicationPump.wrap(ByteBuffer.wrap(buffer, offset, length))
                val resultBuffer = ByteArray(offset + encrypted.size)
                encrypted.copyInto(resultBuffer, offset)
                return ByteArrayWithLimit(resultBuffer, resultBuffer.size)
            } catch (e: Exception) {
                AppLog.e("SSL Encrypt failed", e)
                return null
            }
        }
    }

    override fun setControlRecordListener(listener: (() -> Unit)?) {
        controlRecordListener = listener
    }

    override fun drainControlRecords(): List<ByteArray> = synchronized(this) {
        controlRecords.toList().also {
            controlRecords.clear()
            controlRecordBytes = 0
        }
    }

    private fun runDelegatedTasks(result: SSLEngineResult, engine: SSLEngine) {
        if (result.handshakeStatus === SSLEngineResult.HandshakeStatus.NEED_TASK) {
            var runnable: Runnable? = engine.delegatedTask
            while (runnable != null) {
                runnable.run()
                runnable = engine.delegatedTask
            }
            val hsStatus = engine.handshakeStatus
            if (hsStatus === SSLEngineResult.HandshakeStatus.NEED_TASK) {
                throw Exception("handshake shouldn't need additional tasks")
            }
        }
    }

    companion object {
        // Maximum wall-clock time for the entire SSL handshake loop. Caps worst-case stall at
        // 15 s regardless of how many round-trips remain when the phone stops responding.
        private const val SSL_HANDSHAKE_TIMEOUT_MS = 15_000L

        private fun createSslContext(keyManager: SingleKeyKeyManager): SSLContext {
            val providerName = ConscryptInitializer.getProviderName()

            val sslContext = if (providerName != null) {
                try {
                    AppLog.d("Creating SSLContext with Conscrypt provider")
                    SSLContext.getInstance("TLS", providerName)
                } catch (e: Exception) {
                    AppLog.w("Failed to create SSLContext with Conscrypt, using default", e)
                    SSLContext.getInstance("TLS")
                }
            } else {
                AppLog.d("Creating SSLContext with default provider")
                SSLContext.getInstance("TLS")
            }

            return sslContext.apply {
                init(arrayOf(keyManager), arrayOf(NoCheckTrustManager()), null)
                // Keep the default session cache (size 10, timeout 86400 s) so that a
                // reconnect within the same app session can use an abbreviated handshake.
            }
        }
    }
}
