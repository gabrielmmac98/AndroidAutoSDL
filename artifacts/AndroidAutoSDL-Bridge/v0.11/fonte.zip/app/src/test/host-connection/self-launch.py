#!/usr/bin/env python3
"""Run actual Self launch and service-cancel paths with a queued Main dispatcher.

Android listener, VPN and Activity effects are counters. Coroutine cancellation is real and the queued dispatcher controls delay deadlines; production method bodies are extracted on every run.
"""
from pathlib import Path
import hashlib
import json
import os
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
SRC = ROOT / 'app/src/main/java/com/andrerinas/openheadunit'
OUT = ROOT / 'build/host-connection/self-launch'
OUT.mkdir(parents=True, exist_ok=True)
methods = {}


def member(file, declaration):
    source = (SRC / file).read_text()
    start = source.index(declaration)
    brace = source.index('{', start)
    depth = 0
    for end in range(brace, len(source)):
        if source[end] == '{':
            depth += 1
        elif source[end] == '}':
            depth -= 1
            if depth == 0:
                result = source[start:end + 1]
                methods[file + ':' + declaration] = hashlib.sha256(result.encode()).hexdigest()
                return result
    raise ValueError(declaration)


fixture = (HERE / 'SelfLaunchFixture.kt').read_text()
comm = 'connection/CommManager.kt'
manager = 'connection/self/SelfLauncherManager.kt'
legacy = 'connection/self/launchers/SelfLauncherLegacy.kt'
for marker, file, declaration in [
    ('XYAUTO', 'aap/AapService.kt', 'private fun refreshXyAutoMediaPolicy('),
    ('STATE', comm, 'class Disconnected('),
    ('CANCEL', comm, 'fun cancelPendingSettingsRestart()'),
    ('START', manager, 'fun start(settingsRestart:'),
    ('ADOPT_VPN', manager, 'private fun adoptDummyVpn('),
    ('STOP', manager, 'fun stop(wasConnected:'),
    ('ENDED', manager, 'internal fun onConnectionEnded('),
    ('ESTABLISHED', manager, 'internal fun onConnectionEstablished()'),
    ('STOP_CURRENT', manager, 'internal fun stopIfCurrent('),
    ('ALLOW_LAUNCH', 'connection/self/SelfLauncherServices.kt', 'internal suspend fun ensureLaunchAllowed()'),
    ('LEGACY_RUN', legacy, 'override suspend fun run()'),
    ('LEGACY_WAIT', legacy, 'suspend fun runWifiLauncher()'),
    ('OBSERVER', 'aap/AapService.kt', 'private fun observeConnectionState()'),
    ('MAIN_COMMAND', 'main/MainActivity.kt', 'private fun forceSelfModeLaunch()'),
    ('HOME_COMMAND', 'main/HomeFragment.kt', 'private fun startSelfModeInternal('),
    ('START_ACTION', 'aap/AapService.kt', 'ACTION_START_SELF_MODE       ->'),
    ('CANCEL_ACTION', 'aap/AapService.kt', 'ACTION_CANCEL_WIRELESS       ->'),
]:
    code = member(file, declaration)
    # Main and its delay scheduler are controlled; production launch/delay calls and Jobs remain intact.
    code = code.replace('Dispatchers.Main', 'service.main').replace('this@AapService', 'this@Service').replace('AapService.', 'Service.').replace('AapService::class', 'Service::class')
    if marker == 'MAIN_COMMAND':
        code = code.replace('Intent(this,', 'Intent(service,').replace('startForegroundService(this,', 'startForegroundService(service,')
    fixture = fixture.replace('// ' + marker + '\n', code + '\n')
# Extract the full Self branch of the actual service policy; remaining branches are unrelated
# wireless/USB effects. Fail visibly if its boundary is renamed rather than testing a copy.
policy = member('aap/AapService.kt', 'private fun scheduleReconnectIfNeeded(')
policy = policy[:policy.index('        if (state.holdsRecovery)')] + '    }'
policy = policy.replace('private fun scheduleReconnectIfNeeded(', 'fun applySelfEndPolicy(')
fixture = fixture.replace('// SELF_END_POLICY\n', policy + '\n')
(OUT / 'SelfModeDisconnectPolicy.kt').write_text((SRC / 'connection/self/SelfModeDisconnectPolicy.kt').read_text()
    .replace('package com.andrerinas.openheadunit.connection.self', 'package selflaunch'))
(OUT / 'SelfLaunchFixture.kt').write_text(fixture)
(OUT / 'ProjectionRaiseDeadlinePolicy.kt').write_text((SRC / 'aap/ProjectionRaiseDeadlinePolicy.kt').read_text()
    .replace('package com.andrerinas.openheadunit.aap', 'package selflaunch'))
for name in ['SelfLaunchCoalescePolicy.kt', 'SelfLaunchTimeoutPolicy.kt']:
    source = (SRC / 'connection/self' / name).read_text()
    (OUT / name).write_text(source.replace('package com.andrerinas.openheadunit.connection.self', 'package selflaunch'))
(OUT / 'DummyVpnStartRequests.kt').write_text((SRC / 'utils/DummyVpnStartRequests.kt').read_text().replace('package com.andrerinas.openheadunit.utils', 'package selflaunch'))
(OUT / 'DummyVpnPolicy.kt').write_text((SRC / 'utils/DummyVpnPolicy.kt').read_text().replace('package com.andrerinas.openheadunit.utils', 'package selflaunch'))
(OUT / 'extracted-method-sha256.json').write_text(json.dumps(methods, indent=2))
(OUT / 'WirelessCleanupGeneration.kt').write_text((SRC / 'connection/wifi/WirelessCleanupGeneration.kt').read_text()
    .replace('package com.andrerinas.openheadunit.connection.wifi', 'package selflaunch'))
# Reuse the toolchain selected by run.py, including its installed-Kotlin fallback.
toolchain = json.loads((OUT.parent / 'toolchain.json').read_text())
jars = [item['path'] for item in toolchain['jars']]
cp = os.pathsep.join(jars)
# The extracted service observer also contains the wireless scan-control boundary.
# Share its production policy and recording doubles with the audio lifecycle fixture.
scan_sources = [SRC / 'connection/wifi/scan/ScanControlPolicy.kt',
                SRC / 'connection/wifi/modes/nativeaa/NativeStrategy.kt',
                HERE / 'audio-stubs/WifiLauncherNative.kt',
                HERE / 'audio-stubs/WifiScanControl.kt',
                HERE / 'audio-stubs/VideoFocusEvent.kt',
                HERE / 'audio-stubs/XyAutoMediaSession.kt']
subprocess.run(['java', '-cp', cp, 'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler',
                '-no-stdlib', '-no-reflect', '-nowarn', '-classpath', cp,
                '-d', str(OUT / 'regression.jar'), *map(str, sorted(OUT.glob('*.kt')) + scan_sources)],
               check=True, timeout=45)
subprocess.run(['java', '-cp', str(OUT / 'regression.jar') + os.pathsep + cp,
                'selflaunch.SelfLaunchFixtureKt'], check=True, timeout=15)
