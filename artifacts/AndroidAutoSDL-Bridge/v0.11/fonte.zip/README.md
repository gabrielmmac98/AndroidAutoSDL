# Open Headunit

<a href='https://play.google.com/store/apps/details?id=com.andrerinas.headunitrevived'><img alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png' width="200"/></a>
<a href='http://www.amazon.com/gp/mas/dl/android?p=com.andrerinas.headunitrevived'><img alt='Available at Amazon Appstore' src='https://images-na.ssl-images-amazon.com/images/G/01/mobile-apps/devportal2/res/images/amazon-appstore-badge-english-black.png' width="200"/></a>

<p align="center">
    <img src="https://github.com/user-attachments/assets/579b7b03-23e0-4eda-a05d-c51d28a72113"
    alt="Headunit Logo"
    height="200">
</p>

Open Headunit is an Android app that allows you to turn your Android tablet or phone into an Android Auto receiver. This project is a revived version of the original headunit project by the great Michael Reid. The original project can be found here:
https://github.com/mikereidis/headunit

## NOTE!
**Android Auto 17.4 and newer can prevent legacy wireless triggers from launching projection, including Self-Mode and automated startup via Wireless Helper. Rooted devices have a workaround: re-enable Android Auto's wireless startup receiver.**
Choose from the five options below according to your Android Auto version and setup:
1. **USB Wireless Android Auto Dongle (Recommended):** Hardware dongles provide seamless, hardware-level plug-and-play.
2. **Native Mode:** Direct Wi-Fi Direct or Headunit Hotspot handshake.
3. **Headunit Server (Developer Mode):** An option for wireless projection and Self-Mode without root. On the device running Android Auto, open its developer settings and tap "Start Headunit Server".
4. **Wireless Helper:** The legacy startup flow works with Android Auto up to **17.3**; for **17.4+** on rooted devices, see option 5.
5. **Root workaround (AA 17.4+):** Re-enable `WirelessStartupReceiver` with one root command to restore the previous wireless startup flow, including Wireless Helper, without starting the developer headunit server. See [the command and setup below](#5-root-workaround-for-android-auto-174).

## Screenshots
<img width="1280" height="800" alt="image" src="https://github.com/user-attachments/assets/6ed31626-480e-404f-ba7a-753b14230a02" />
<img width="1280" height="800" alt="image" src="https://github.com/user-attachments/assets/ce67584e-fcf6-4308-b11a-116780df47f7" />
<img width="1280" height="800" alt="image" src="https://github.com/user-attachments/assets/fc2870be-a173-4113-8187-4835bd564842" />


## How to use
**Check out the [Wiki](https://github.com/andreknieriem/open-headunit/wiki) for detailed documentation, setup guides and troubleshooting!**

### Wired USB Connection
- Connect your Android device (phone) to the tablet running Open Headunit via USB cable.
- Make sure that Android Auto is installed on your phone.
- Set your phone to Host-Mode if nescessary and select Android Auto
- Click the USB Button in Open Headunit, find your phone and click the right button to allow connection
- Click on your phone in the list and wait for Android Auto to start

### Wireless Connection Options
Choose from the five options below depending on your Android Auto version and setup:

#### 1. USB Wireless Android Auto Dongle (Most Reliable)
- A standard hardware USB Wireless Android Auto Dongle (plugged into the headunit) handles the entire wireless negotiation independently.
- Provides seamless plug-and-play connection regardless of phone Android Auto version.

#### 2. Native Mode (Wi-Fi Direct / Headunit Hotspot)
- Directly communicates with Android Auto's native wireless protocol without helper apps.
- Supports **Wi-Fi Direct (P2P)** or the **Headunit Hotspot** transport.
- Configure under Open Headunit Settings -> **Android Auto Mode** -> **Native Mode**.

#### Optional automatic Wi-Fi scan pause

In advanced settings → **Wireless Connection** → **Pause automatic Wi-Fi searches**, enable
**Pause during wireless connections**. It is off by default and applies immediately. The setup
screen puts installation and app approval under **Common setup**, vendor startup under
**On FYT devices**, and manual debugging instructions under **On other devices**.

- **Android 13+:** in Native mode (Wi-Fi Direct or Hotspot), pauses Android's periodic connectivity and PNO searches through the global
  autojoin gate. Client modes keep automatic reconnection enabled. It reads the original value before changing it and restores that value on disconnect.
- **Android 11–12L Wi-Fi Direct:** disables global autojoin through Shizuku while keeping
  the P2P group. These versions expose no state getter: on release, searches are enabled again,
  even if they were disabled beforehand. Command acceptance is not a measured scan state.
- **Android 8–10 Wi-Fi Direct:** disables the internal connectivity manager through Shizuku.
  Apply on connection, then renew every five minutes while connected. Android network requests
  can re-enable searches between renewals. The long interval limits repeated firmware roaming
  cleanup on Android 8–9; this is best-effort, not a guarantee of continuous suppression.
  Release enables the manager again; the previous
  value cannot be read. Reboot resets these temporary legacy Direct controls.
- **Android 8–12L Hotspot:** with ordinary Wi-Fi off, pauses the remaining scan-always path
  and restores its recorded value. The app never turns off a live Wi-Fi Direct radio.
- **Android 7 and older:** this option is unavailable; existing wireless behavior is unchanged.

Android 11+ can start Shizuku through wireless debugging; the screen also points to its USB setup
for devices without that option. Android 8–10 uses USB/computer setup, with an explicit on-device
startup option on supported FYT systems. FYT startup asks for normal ADB RSA authorization and
keeps its network ADB listener open, including after app restart. Use **Close wireless ADB**
to restore paused Wi-Fi searches and then stop the listener opened by this app. If restoration
cannot finish, ADB stays open for recovery. Closing can also stop Shizuku and disconnect USB debugging.
Existing ADB ports and persistent settings are left alone. An interrupted explicit close is
retried when the app reopens. On Android 8–10 FYT systems, a previously configured FYT start is
attempted when a Native wireless transport opens, provided this option stays enabled and Shizuku
is not already running. App launch and boot alone do not start it. The attempt runs alongside the
Android Auto handshake and does not delay projection. Each connection gets at most one attempt;
disconnecting cancels unfinished startup. USB, self and wireless client sessions are excluded.
Explicitly closing ADB disables automatic startup until the FYT start button is used again.
Android may still require debugging authorization; failure does not block Android Auto.

On app-process death, a separate shell helper attempts rollback. A device-local recovery record
survives interruption of both processes and is retried when Shizuku is available again. Pending
recovery is shown on the home screen and in settings, with automatic retries while an authorized
helper is available. For a legacy scan-always recovery, Android can also restore scanning through
a system confirmation without restarting Shizuku. Where the state can be read, the app verifies
restoration before clearing its recovery record. Legacy Direct clears the record after Android
accepts the enable request. On paths with readable state, if searches are re-enabled elsewhere,
the app leaves them enabled for that connection instead of repeatedly forcing them off. Other apps' explicit scans, Wi-Fi Direct discovery and firmware roaming are outside
this control; this option cannot promise to eliminate every radio interruption.

#### FYT external Bluetooth module transport (experimental)
On FYT units where the phone pairs for calls with a separate Bluetooth module (for example **DUDUAUTO** on DUDUOS), Native Mode can carry its Android Auto Bluetooth handshake through `/dev/auto_serial`, the relay the stock Car Link app (`com.syu.carlink`) uses, while calls remain on the module and the vehicle microphone/speakers. Tested so far only on DUDUOS with a BLINK module.

Requirements:
- An FYT unit that exposes `/dev/auto_serial` (Car Link's external-module backend, `sys.fyt.bluetooth_type` above zero).
- Nothing extra where the node is app-openable, as it is for the stock Car Link. Where it is not (node mode or SELinux), root access for Open Headunit, used as a fallback.
- The stock `com.syu.carlink` package disabled, because two readers on the same terminal split protocol messages.
- The phone paired with the module; pairing and phone priority remain managed by the module.

Setup:
1. Disable the stock client: `adb shell pm disable-user --user 0 com.syu.carlink` (prefix with `su -c` if the shell refuses).
2. In Open Headunit, select **Native Mode** and enable **Connect through the FYT external Bluetooth module**.
3. Keep the phone paired with the module and connect normally.

On a detected FYT module unit with this transport off, Native Mode refuses to start and names this setting, instead of listening on a radio the phone is not paired with. If the channel cannot be opened (Car Link still enabled or running, or the node not app-openable and root denied), the reason is shown on screen and retried with a growing delay.

Android Bluetooth driver selection, preferred-phone and wake-list controls are intentionally hidden on this route because Android cannot see or dial phones bonded to the external module. To roll back, turn this transport off and re-enable the stock client with `adb shell pm enable com.syu.carlink` (prefix with `su -c` if needed).

#### Bluetooth Relay (ESP32 Classic BT relay)

Native Mode can route the Android Auto Bluetooth handshake through an original ESP32 acting as a classic Bluetooth RFCOMM relay. Phone traffic uses RFCOMM; the head unit uses BLE GATT write / indicate. The ESP32 does not parse Android Auto (WPP) payloads; WifiStart / WifiInfo and the rest of the handshake remain on the head unit.

Firmware, prebuilt binaries, and flashing: [aa-native-bt-broker-for-openheadunit](https://github.com/kendrickkim/aa-native-bt-broker-for-openheadunit) ([v1.0.0](https://github.com/kendrickkim/aa-native-bt-broker-for-openheadunit/releases/tag/v1.0.0)).

Requirements:
- Original ESP32 with Bluetooth Classic. ESP32-S2 / S3 / C3 / C6 lack Classic BT and are unsupported.
- Head unit on Android 6.0 (API 23)+. Below API 23 the Bluetooth relay settings row is not shown.
- Wireless connection mode: **Native**.

Bonding topology (required):
- Head unit bonds to the ESP32 BLE advertiser `OpenHU-BT-Relay-Setup` (address stored under Settings → Bluetooth relay). The head unit does not Classic-bond to the phone on this path.
- Phone Classic-bonds to the ESP32 `OpenHU-BT-Relay`(PIN `0000`).
- Cached Bluetooth names may lag after a re-configuration; delete the entry and rescan.

Settings:
- Enable **Use Bluetooth relay** under **Settings → Bluetooth relay (ESP32)**, then scan and select the relay.
- Disabling the switch retains the saved relay address but returns Native Mode to the normal Bluetooth driver path.

Setup (sequence is mandatory; BLE relay selection must precede phone Classic pairing):

1. On the phone, remove the head unit from the Bluetooth bond list, then remove any existing `OpenHU-BT-Relay` entry.
2. Power the ESP32. On the head unit open **Settings → Bluetooth relay (ESP32)**, enable the relay, **Scan**, and select `OpenHU-BT-Relay-Setup`. Selection stores the relay and opens a 120 s Classic discoverable window (status: pair `OpenHU-BT-Relay`, PIN `0000`).
3. On the phone, pair `OpenHU-BT-Relay` (PIN `0000` if prompted). Confirm paired / connected status on the head unit.
4. Start Android Auto under Native Mode. Wake / dial toward the phone is issued through the relay.

HFP behaviour: after initial pairing the relay drops HFP. A transient phone-side “Bluetooth failed” indication at that point is expected. On each Native AA start the relay briefly re-enables HFP to deliver connection parameters, then disables it again. The window is handshake-only and is not intended to carry ongoing calls.

Troubleshooting:

| Symptom | Action |
|---|---|
| Discoverable window expired before Classic pairing | **Settings → Bluetooth relay (ESP32) → Pair phone** reopens the 120 s window. |
| BLE scan empty | Reset the ESP32 and scan again. |
| Android Auto does not start | Ensure the phone has no remaining bond to the head unit. |

#### 3. Headunit Server (No-Root Option for Self-Mode on AA 17.4+)
- Starts the native Android Auto developer server directly on your phone or on the same device (Self-Mode).
- **Setup:**
  1. Open Android Auto settings on your phone (or tablet in Self-Mode).
  2. Scroll down and tap **Version** 10 times to unlock Developer settings.
  3. Tap the three-dot menu in the top right corner and choose **Start headunit server**.
  4. In Open Headunit, tap the **WiFi** button to connect (or use Self-Mode).

#### 4. Wireless Helper
- Our companion app triggers the wireless connection automatically in the background.
- **Compatibility:** Android Auto **v17.3 and below**, or **v17.4+** with the root workaround in option 5.
- **Download:** [Wireless Helper on Google Play Store](https://play.google.com/store/apps/details?id=com.andrerinas.wirelesshelper)
- **Setup:** Set Open Headunit Wireless Mode to **Helper Mode**, ensure both devices are in the same network or Wi-Fi Direct group, and start the service in the Wireless Helper app.

#### 5. Root Workaround for Android Auto 17.4+
On the device running Android Auto (normally the phone), open a **root shell**, for example by running `su` in a terminal and granting root access. Then run:

```sh
pm enable --user 0 \
com.google.android.projection.gearhead/com.google.android.apps.auto.wireless.setup.receiver.WirelessStartupReceiver
```

Re-enabling this receiver restores the previous wireless startup flow on affected Android Auto versions. Keep using the same Wireless Helper / Helper Mode setup as before; the developer headunit server is not required for this workaround. Root is needed on the device running Android Auto, not on a separate head unit.

`--user 0` targets the primary Android user. This is an internal Android Auto component: the workaround requires it to exist in the installed version, and future updates may change its name or behavior.

### Connect Wirelessly via Intent (Power Users)
You can trigger a wireless connection attempt using an Android Intent. This is useful for automation tools like **Tasker**, **MacroDroid**, or via **ADB**.

**URI Scheme:** `headunit://connect?ip=<PHONE_IP>`

**Example ADB Command:**
```bash
adb shell am start -a android.intent.action.VIEW -d "headunit://connect?ip=192.168.1.25"
```

## Known Issues
- **Google Maps in Portrait Mode:** Touch interactions (searching, scrolling) within Google Maps may not work as expected when using Portrait Mode on some devices. **Fix:** Try reducing the **Pixel density (DPI)** setting to **below 200** (e.g., 190) in the app settings. This often restores full functionality.
- **Wireless Connection Drops:** If the connection drops frequently, disable **"WiFi Assistant"** or **"Switch between networks"** in your phone's WiFi settings to prevent it from killing the connection due to "no internet." Check battery saving options.
- **Self-mode on Android 10 (Q) and below:** Google has disabled the automatic wireless projection startup for Android 10 and below in Android Auto versions 16.4 and higher. While Self-mode still works on newer Android versions, it is normally impossible to trigger projection on Android 10 and below directly with recent Google app updates. **Workaround:** You can still use Self-mode on these devices by starting the built-in Android Auto Headunit Server and connecting via Wi-Fi mode (loopback). See the [Troubleshooting Guide](https://github.com/andreknieriem/open-headunit/wiki/Troubleshooting#self-mode-on-android-10-q-and-below) for step-by-step instructions.
- **WiFi-Direct needs long to connect:** A user finds that this is related to Google Assistant instead of Gemini for AA. If you use Gemini on newer AA versions it just runs smooth again. No idea why this happens.
- **Stuck on Android is starting** Check your video codec in the settings and set it to h264 if you have a device which does not support h265. Some devices have a broken h265 decoder and this will cause the app to stuck on "Android is starting" and never start the projection.

## Planned
- more customization options for the UI and the app itself
- Info/Help descriptions to the settings for better understanding

## Changelog
### 4.0.0-beta1
- New Homescreen, thanks to @andrecuellar
- AAP: send one version request over TCP, so a slow head unit server is not left deaf
- AAP: Keep media and navigation display updates off the receive path
- AAP: Preserve frame boundaries during handshake
- AAP: send one version request over TCP, so a slow head unit server is not left deaf
- WiFi Direct: detect a wedged P2P stack and offer a WiFi restart
- WiFi: Pause automatic searches during wireless sessions with Shizuku
- Native AA: remember a unit that refuses every banded WiFi Direct group
- Native AA: connect faster
- Wizard: test the decoder before recommending settings
- Fix(usb): Resolve dongle AOA switching
- Status pill: stop saying Android Auto is starting when nothing is
- Projection: keep the decoder through a short cover
- Display: size Automatic DPI to the panel, and keep the widescreen layout it already had
- Video: Add H.264 support to bundled FFmpeg
- Logs: name captures OHU_Log_ instead of HUR_Log_
- Audio: Reduce renderer work and add independent music correction

### v.3.5.0
- Native AA: reconnect to a network that is still there, wake the phone over Bluetooth or the external module, bring a lost group or hotspot back after sleep, boot or ACC wake, stop advertising an address that moves, and pick, wake or hold back only for a phone that is on
- Wireless: BSSID recovery via IPv6 EUI-64, keep the station stood down mid-session, hold every automatic bring-up while the unit is asleep, and log a refused start at boot instead of crashing
- Added: Option to use Open Headunit as a launcher, thanks to @amp3r1 for some improvements
- Added: Simplified Chinese 🇨🇳, Indonesian 🇮🇩, Hindi 🇮🇳, Thai 🇹🇭, European Portuguese 🇵🇹
- Connection: one attempt at a time, hold auto-connect behind settings and the pill's X, and fix the dongle's TLS handshake
- Add on-demand "Check for Updates" button
- Add FYT BLINK/DUDUAUTO module transport for Native AA thanks to @dohun0310
- Added: Apps drawer, thanks to @amp3r1
- Navigation: stop the road name from sticking after the road changes
- Self Mode: release the dummy VPN once the session is up, and start none for Android Auto 17.4 and later
- Video: no codec on a dying surface, a picture after a screen-off return in Texture mode, and a 720p fallback the phone can pick on a 2.4 GHz link
- Automation: restore the three dropped automation commands, and stop Headunit Server connects preempting each other
- Fix: crash when the USB service is missing, thanks to @muayyad-alsadi
- Added: Performance overlay with its own settings screen, choose which lines it shows
- Added: Root workaround for Android Auto 17.4+ wireless startup in the README, thanks to @mixalbl4-127
- Wireless: request low-latency Wi-Fi during projection, and keep active WPP control connections with isolated listener generations, thanks to @emotionbug
- Audio and mic: stabilize playback and AAC recovery with opt-in AAudio, honor the device's buffer minimum, smooth PCM transitions, isolate capture sessions and bound uplink flow control, thanks to @emotionbug
- Protocol and TLS: unify AAP framing and message reassembly, keep payloads across application-phase control records, and send the final ByeBye first, thanks to @emotionbug
- Connection: serialize session replacement, reconnect audio settings, cancel obsolete reconnect timers, and keep Nearby tunnels within their attempt, thanks to @emotionbug
- Video: isolate decoder workers and retire activity-owned surfaces, thanks to @emotionbug
- Floating button fixes and a connection status option, thanks to @Sesam17
- USB: recover a stale phone without a replug, keep the phone's Media audio on if you choose, and stop reconnecting when no screen comes up
- Settings: Exit in Android Auto ends the session again, Save writes only what changed, and the setup wizard sets the DPI again and asks for the vehicle type
- Updates: open the release APK itself on units below Android 5.0
- Audio: no more stutter or crackle with the Mgear Mstick4 dongle (firmware 1.9.4), thanks to @emotionbug
- Self Mode: leave the media buttons and the media widget to the phone's own player, thanks to @Duzttt
- Keymap: send letter keys to Android Auto, and give the night mode key its own entry, thanks to @Duzttt
- Home: grey out the connection buttons you did not choose, thanks to @amp3r1
- Night mode: new "Automatic (System)" option follows the system dark mode, thanks to @MohmmadQunibi
- Settings: Enter saves a text dialog when the keyboard covers its buttons, thanks to @mohammed-just
- DPI: fix the reduced Android Auto layout on small screens

### v.3.4.0
- USB: connect non-Pixel phones without fighting a fast-reverting dongle
- Feat/automation command surface
- Video-Fit and ultrawide touch enhancements with dynamic scaling and rework all the options, thanks to @o-jardenass and @Sesam17
- Several enhancements for native mode, thanks to @o-jardenass
- Added darkmode for splashscreen
- Added ADB-Server to disable/close OEM apps like Zlink, Autokit etc. to reduce conflicts with OpenHU
- Added Support for BYD Steering wheel keys, thanks to @nicoruy
- Added floating Exit Button, thanks to @Sesan17
- Added Log to clipboard, thanks to @peter9811
- Native for External BT's + Connection Status pill + AAC improvements to @o-jardenass
- Moved Ui-Scale to theming
- Native AA: say when the unit's WiFi radio is off instead of retrying in silence
- Fix: Endless Loop in Permission Requests.
- Give Video its own transport thread
- Stop old Android promising what it cannot do
- Measure and size the audio sink

### v.3.3.1
- Added: Option to auto-resume media playback on quick reconnect if music was playing before disconnect
- Fixed: Errors shown in playconsole
- Big Improvements to native mode. Huge Thanks to @o-jcardenass for this!

### v.3.3.0
- Begin for theming of the App.
- Refactor WiFi-Code from AapService into their own classes for better maintenance, thanks to @MrEAlderson
- Refactor Self-Mode and USB-Mode from AapService into their own classes for better maintenance, thanks to @MrEAlderson
- Refactor Audio and Video Code from AapService into their own classes for better maintenance, thanks to @o-jcardenass
- USB-Blacklist Filter to prevent the app from asking for non Android phones
- Added: Option to disable the clock, thanks to @MrEAlderson
- Added: French translation 🇫🇷 thanks to @phiDu-fr
- Fix/session lifecycle and video concealment
- Video: pace the transport thread instead of shedding reference frames
- UI: a destroyed activity stops listening, and a recycled row keeps its subtitle
- Fix Android 4 Problems
- Fix Orientation issues
- Several Native Mode fixes and enhancements
- Mic: fix the uplink, and let the phone keep the microphone
- Fix: Close keyboard that stays open on older Android versions to prevent layout issues
- Per-channel audio stream selection, thanks to @nicoruy
- Added Android Auto 17.4 Notice for users, who don't know why their wireless setup broke
- Clean Up Dark Mode and Theming Option confusions
- Fix: Projection dies when a Bluetooth keyboard connects or disconnects

### v.3.2.6
- Fix settings UI crash and dpi input on older Android devices
- Fix video artifacts
- Fixing wireless stack where failures stay broken until restart
- Bringing back old style USB List
- Fix broken theme after import: Reapply Theme selection after Settings import
- Make HUD Mode for apply for the whole app

### v.3.2.5
- Fix black screen after backgrounding, and the washed-out picture a dropped frame leaves
- Fix headunit server socket leak
- Car GPS: deliver the head unit's fix when the phone asks, and keep it flowing

### v.3.2.4
- Fix: Video and audio never catch up after a wireless link stall, thanks to @o-jcardenass
- Fix: Native AA wake poke takes down the head unit's own hands-free link, thanks to @o-jcardenass
- Stop the setup wizard from overwriting the reported manufacturer, thanks to @o-jcardenass
- Added: Let the Bluetooth side keep the media buttons,  thanks to @o-jcardenass

### v.3.2.3
- Adding custom log location (App folder or Download folder)
- additional fixing for the fps/freeze problems. Thanks to @o-jcardenass and @andrecuellar for helping
- Fix/hotspot unreadable config
- NativeAA: show when a P2P group that lands on channel 12 or 13

### v.3.2.2
- Fixing location jumping, especially on lower speeds
- Fixing screen flicker again in video decoder
- Fix/video throughput telemetry and keyframe lockout, thanks to @o-jcardenass
- Fix Steering Wheel Buttons not working anymore
- added new native mode without WiFi-Direct creation, thanks to @o-jcardenass

### v.3.2.1
- Fixing new welcome screen reappears, thanks to @andrecuellar
- Fixing screen flicker every 10s thanks to @o-jcardenass
- Fixing HW decoding on kitkat thanks to @o-jcardenass
- Fixing 2 Fatal errors shown in play console
- fix: move mic timestamp inside encrypted payload (byte 4), thanks to @bruno303
- making native mode work better and on more devices, thanks to @o-jcardenass

### v.3.2.0
- Don't grab audio focus on connect in dynamic mode, thanks to @bnayahu
- Acquire transient audio focus while AA audio plays, thanks to @bnayahu
- Add GitHub Actions CI (build + unit tests), thanks to @bnayahu
- Fix picture stuck if used within DUDU's PiP, thanks to @MrEAlderson
- Fix(wifi): use public API for frequency, thanks to @DerTeufel
- Added pixel aspect ratio setting, thanks to @axel92b
- Added more audio features to gain audio focus and work with dsp headunits as setting
- Added display over other apps permission for better compatibility with some headunits, espacially with self mode
- Fix transport get stucked on multiple reconnects, thanks to @notathf
- Add car keys support for FYT headunits, thanks to @MrEAlderson
- Added Option to flip projection horizontal for Headup-Displays
- Recover automatically from post-first-frame video display stalls, thanks to @andrecuellar
- Settings and Onboarding Wizard redesign for better usability, thanks to @andrecuellar
- Fixing mulitiple WiFi-Direct and Native AA connection issues, thanks to @o-jcardenass, @andrecuellar and @notathf
- Various fixes PR, thanks to @MrEAlderson
- Selfmode on AA 17.4 now connects to the headunit dev server or opens the AA settings to start it
- Rename the app to Open Headunit because of confusion with Headunit Reloaded (HUR)

### v.3.1.1
- Reduce pressure on sensor events like night and gps and start/stop these events in onConnected, onDisconnect and onDestroy
- Merged ffmpeg PR #625 by @mmwtl. This added ffmpeg software decoder for h265, which old devives could benefit a lot. Thank you!
- Wi-Fi Direct changes. Prevent duplicate start, graceful resets, cleaned up stale groups
- Remove Automatic Play Integrity Checks, so Playstore won't check the license and link to the playstore in headunits
- Added manual bssid for native Mode. This should help for users where the bssid is hidden for the app, thanks to @rakshan-kumr
- Added immediately network scan with wifi connection, thanks to @MrEAlderson for the PR

### v.3.1.0
- Added libusb as alternative to the native usb stack for better compatibility with some devices
- Fixed Layout in Portrait Mode in nearly square devices
- Added Scale Slider for loading screen media

### v.3.0.1
- Fixed: App Exit on Disconnect
- Enhanced: USB Workflow. This will hopefully eliminate some random usb disconnects
- Fixed keyboard input on Android < 6 Devices
- Enhanced WiFi Direct-Mode
- Enhanced File Selector for some devices
- Fixed some fatal errors, showing in play console

### v.3.0.0
- Added: Custom loading screen (image/GIF/video), thanks to @andrecuellar
- Added: Settings-Reset Button, if you mess up something in the settings, you can now reset them to default
- Removed: Old deprecated ssl library written in C-Code for better maintenance, stability and smaller file sizes
- Added: Direct Logging to file without logcat, thanks to @Anton111111
- try to fix connection lost on carrier lost again
- keep usb disconnection for 8s alive, for maybe restarts of usb dongles
- Implement car headlight signal mode (ILL+) for night theme management, thanks to @minhtuanact
- Added settings export and import functionality with backup options, thanks to @JanRi3D
- Added whitelist to usb connection for not interrupting with iPhones and other usb devices
- Added QR Code for easy connection with wireless helper
- Fixed: BT auto-connect dragging phone into wireless flow during USB session, thanks to @andrecuellar
- Persist Auto-Optimize wizard settings synchronously, thanks to @andrecuellar
- Added ability to swipe with two fingers from the right side to switch fullscreen mode and Normal (all bars) mode, thanks to @Anton111111
- Improved: usb button auto connect, thanks to @bezprobeloff
- Catched an fatal error listed in the play console
- Fixed: Audio Stutter on some devices since 2.1.1
- Fixed: USB device list duplicates and Android Auto projection launch on Android 10+, thanks to @jeancarloscc
- Enhanced: Google Nearby. It was buggy with 2 FPS video
- Fixed: Navigation Button mapping now working

### v.2.3.1
- Fixed a connection lost on for example borders
- Binding socket to wifi network if available to prevent connection drops on carrier lost
- Added Static Audio Focus Toggle to prevent audio focus loss on some devices
- Fixing samsung routines and modes
- Fixing wrong orientation on start if holding the phone wrong. Now uses the orientation from settings
- Try to fix usb errors with AAwireless Dongles
- Added Audio Mixer to mix different audio tracks, thanks to @jeffdapaz for the idea
- Added Autostart on BT for multiple devices
- Fixed Microphone input source was wrong mapped
- Added Vietnamese translation 🇻🇳 thanks to @minhtuanact
- Merged PR #549 - implement back key routing and add keymap for back key, thanks to @JanRi3D

### v.2.3.0
- Added some new buttons for keymap
- Fixed 3 Fatal errors
- Fixed video decoder settings for allwinner devices
- Added new navigation intents
- Included PR #456
- Added new "Autostart on WiFi" Setting #324
- Fixed empty bssid on native AA. Should now work on more devices
- Fixed a new fatal with media sessions
- Readded fullscreen overlays system icons #351
- Remap Enter (66) to Dpad Center (23) for Rotary Knob #459
- Debounce multiple key events if key event is the same in 100ms #465
- Moved Mic settings to own fragment and added 3 new options for the new mic enhancement from version 2.2.2, which defaults to off for better compatibility
- Merged PR #481 - Apply MediaTek 60fps and audio optimizations, thanks to @mrkontrast-coder
- Some rewrite of the AudioTrackWrapper, to enhance stability and minimize stutters
- Merged PR #490 - Add UI scale settings, thanks to @Anton11111
- Merged PR #502 - Navigation Broadcast Updates. Thanks to @Bastel2020

### v.2.2.2
- Fixed: Exit on disconnect now stops the carmode too
- Fixed: Exit intent not closing the app
- Fixed: Orientation not working great on app switch, if you have "auto or sensor" enabled
- Again: Steering Wheel and Keymapping got some changes, maybe this will work on more devices
- Extend mic debugging and add NoiseSuppressor, AutomaticGainControl and AcousticEchoCanceler for better voice quality
- Fixed an issue where the Android USB system prompt wouldn't appear for phones. The prompt is now enabled by default and can be separately disabled for USB thumb drives. It calls "Listen for USB Devices" setting and it decouples the system USB prompt from the Auto-Start behavior. This will bring back the old functionality for all and can be disabled for those who are annoyed of the popup for non Android Auto devices
- Fixed: Rescale and UpdateUI if the useable area differs from the one negiotated. This happens on devices which lie about their navbars.
- Fixed: Fatal Crash on devices below lollipop on disconnection
- Fixed: Auto-Night mode over 3 hours of in the UK and other countries, thanks to @BinarySimple17
- Add separate audio streams setting and update related functionality thanks to @Anton111111
- Enhanced: When audio sink is off, the app no longer tries to get media focus at all

### v.2.2.1
- **Fixed a fatal error in UBS conncetions since 2.2.0. This is important so releasing this version while not fixing all planned issues**
- Google Nearby Connection is now auto connecting if auto connect is enabled
- UI: Added Error Message for Android 10 and below for selfmode
- New Approach for scaling and touch to prevent offset
- Fixing App appears multiple times in App-Drawer
- Fixing Routines and intents not working

### v.2.2.0
- Added: Native AA. 🎉  Warning! This will only work on a limited amount of headunits! Most Android devices do not support connecting 2 Android devices via Bluetooth which is essential for this to work.
- Added: Google Nearby Support as connection method. Needs Wireless Helper 1.6.0 or later
- Added: Pip-Support
- Added: 4K in select
- Try to fix connection problems on WiFi
- Added: Intent and routine for starting the app directly to self mode
- Added: Force Scale Option for older devices on surface view
- Added: New Immersive Fullscreen with avoided notch area. This should fix problems for eg. Pixel Phones
- Enhanced: Video Decoder Error Handling
- Added: 2 new WiFi-Options for a WiFi-Direct. Thanks to @andrecuellar
- Added Japanese language 🇯🇵 thanks to @mattyann87
- Enhanced: Media Session Announcement. Thanks to @irwanrhmn
- New App-Icon without text for better visibility
- Fixed: USB modal appearing for non-Android Auto devices thanks to @andrecuellar
- Added: Create configurable audio queue and audio buffer in settings thanks to @irwanrhmn

### v.2.1.1
- Fixed: Layout crash on Android 4.2
- Added: Enable Hotspot option. Note: This will not work on every device. Especially after Android 13!
- Added: Fake VPN Handler for new Android Auto in offline mode. It is no longer possible to send a network to AA, so we need this hack, if your device is offline
- Enhanced: Audio-Focus is now more aggressive to hopefully fix the audio is not coming from my tablet/headunit errors
- Added: Auto-Boot Functionality. Thanks to @andrecuellar
- Attention: Needed to split Github and Playstore Release. Google does not allow using Fake VPN for offline selfmode. This is now not included in the playstore release!

### v.2.1.0
- Fixed: Exit Intent not working. Thanks to benyjr
- Added: Rotary Support
- Fixed: Crash in Android < 5
- Fixed: Double Button fire and enter/knob click as dpad center mapping
- Enhanced: Android Auto start for selfmode now tries all methods always and catches errors
- Fixed: Auto start, connection lost overlay, toasts and API17 Bluetooth crash. thanks to @andrecuellar
- Added: Exit App on disconnect feature/setting thanks to @Tilak-03 and @andrecuellar
- Enhanced: Wi-Fi Setting redirect is gone. Now only a toast message
- Fixed: styling errors

### v.2.0.2
- Fixed: 60FPS never applied
- Fixed: SSL Handshake fix for truncated messages
- Added: dark mode and xtreme dark mode setting for the app itself thanks to @andrecuellar!
- Removed: App category="maps" so nav buttons recognize the app again
- Fixed: Multiple Button Events and double/tripple skips
- Fixed: USB Permission Request thanks to @Bastel2020
- Added: Setting for Disable stretch to fit. This will fix  wrong rendering on some devices @thanks to tsabaia
- Fixed: Touch screen accuracy when not in full screen mode for older devices
- Fixed: Big Icon-Button on main screen when the dpi is small and the screen is wide

### v.2.0.1
- Fixed: Multiple volume sliders appearing on modern devices (Pixel 9 fix)
- Added: Support for Media Button emulation (SWC improvement for MacroDroid etc.)
- Added: App shortcut and deep link for full app exit (headunit://exit)
- Added: Improved Wi-Fi Direct reliability with recursive discovery and ping handoff
- Added: Romanian translation 🇷🇴, thanks to @LeeWiu
- Merged PR #189: Adding navigation message handling, thanks to @Bastel2020
- Merged PR #215: Fix USB reconnect race and stale dongle data after AA exit, thanks to @andrecuellar
- Merged PR #205: Fix wireless dongle disconnect on network changes, thanks to @andrecuellar
- Merged PR #216: Add Bluetooth SCO microphone support, thanks to tgigli

### v.2.0.0
- Added Wi-Fi Direct (P2P): Support. Connect your phone to the headunit without a shared network or hotspot. The headunit now automatically becomes visible as a P2P peer.
- Refactored Connection Core: Complete rewrite of the internal connection handling using the new **CommManager**. Improved stability, faster handshakes, and better coroutine integration.
- Enhanced Fullscreen Logic: Choose between "Immersive" (hide all), "Status Only" (keep navigation bars), or "None". Improved compatibility for devices where buttons were previously obscured.
- Added Auto-Optimization Wizard: Automatically recommends the best Resolution, DPI, and Codec for your specific hardware.
- Added Early MediaSession Initialization: Fixes audio routing issues where the phone would sometimes play sound through its own speakers instead of the headunit.
- Added New Logging System: Integrated log level control and file capture for easier debugging.
- **IMPORTANT** Fixing Android Auto 16.4 intents for selfmode. In Wireless Helper too. Please update to 1.2.0

### v.1.15.1
- New Feature: Added Auto-Optimization Wizard to automatically find the best Resolution, DPI, and Codec settings for your hardware.
- Bugfix: Fixed Self Mode failing to start in offline/hotspot scenarios (Network ID 0 fix).
- Bugfix: Improved Audio Routing. The phone is now more likely to route audio to the headunit immediately upon connection by using an early-initialized MediaSession with remote playback metadata.
- Bugfix: Fixed GPS Speed calculation. Speeds were previously doubled due to an incorrect unit conversion (knots instead of mm/s).
- UI: Improved Settings readability on small screens by allowing multi-line descriptions.

### v.1.15.0
- Added arabic language thanks to A5H0
- Added new intent for setting day/night mode for maps
- Added new window flags for older devices to finally fix fullscreen issues
- Added new intents to make the headunit recognize the app as navigation app
- Added LegacyOptimizer which will handle things directly and faster for single core cpus. Should improve the performance on Android 4.1 - 4.4 Devices
- Fixed BT Permission Bug
- Changed the Twilight-Calculator for better switch to day/night on auto mode to prevent to bright display
- Added more mediasession logic to gain audio focus and audio routing
- Merged Retry Button on connect screen, thanks to @andrecuellar
- Merged auto connect usb feature, thanks to @andrecuellar

### v.1.14.3
- **Automation:** Added App Shortcuts for Samsung Modes & Routines support.
- **Navigation:** Officially registered as a navigation provider (compatible with NAV buttons).
- **Stability:** Fixed rare app freezes by improving internal data handling and memory hygiene.
- **Compatibility:** Improved hardware support for Amazon Fire Tablets and GPS-less devices.

### v.1.14.2
- Bugfix: Notification and Exit Button do not close the app
- Improvement: Removed old legacy Invisible Bluetooth Setting to prevent Bluetooth from start on the whole time

### v.1.14.1
- Improvement: Integrated USB Auto-Connect into "Auto-Connect Last Session". App now behaves like a native headunit and connects automatically on startup or USB plug-in.
- New Feature: Added USB Soft-Reset logic. Automatic recovery from USB "stalls" without needing to replug the cable.
- Major Improvement: Audio focus and routing overhaul. Added `MediaSession` support and immediate focus response to phone. Fixes issues where background apps on the tablet would block Android Auto audio.
- Improvement: Robust Task Switching. Leaving the app via Home button or clicking the Launcher icon no longer breaks the connection. Music continues in background, and clicking the icon/notification correctly returns to the projection.
- New Feature: Enhanced Key Debugger ("Key-Sniffer"). Prominent display of all key events, including special characters (ö, ü, ß) and proprietary steering wheel intents (MTC, FYT).
- New Feature: Official Navigation App Registration. OpenHU is now recognized as a navigation provider (`geo:`, `google.navigation:`, `android.intent.action.NAVIGATE`). Compatible with hardware "NAV" buttons.
- Bugfix: Removed redundant "Already connected" and "Reconnection required" alerts for a smoother user experience.
- Localization: All new strings translated into 10 languages.

### v.1.14.0
- Added Separate volume setting #91
- Added Auto-Start on Bluetooth Option
- Merged PR #134 - Fixing Connection on Mediathek Headunits
- Merged PR #131 - Fixes SystemUI on < Android 6 Devices
- Merged PR #127 - Fixing Audio Truncation

### v.1.13.3
- Fixed Screen Issues on Android 4 with header and navigations #114
- Fixed Night-Mode Bug #116
- Merged several PR for better Language Handling with a new language selector. Thanks to @andrecuellar

### v.1.13.2
- Fixed margins now working for devices prior Android 5 Lollipop
- Fixing warnings
- Fixing broken colors on mixed daynight values
- Fixed a bug where a message is bigger than thought after about 20 minutes and connections closes

### v.1.13.1
- Fixed Custom Insets Dialog with a Scrollview
- Fixed 4 app crashes listed in play console
- Fixed 2 warnings in play console for edge-to-edge display
- Fixed a race condition in ssl read/write
- Preventing disconnect if just one package was broken/corrupt in ssl transfer

### v.1.13.0
- Improvement: USB stability overhaul (implemented 16KB internal buffer)
- New Feature: Custom Insets (Margins) setting with live preview
- Fixed: Video decoder blackscreen on some AI-Boxes (H.264 NAL padding)
- Fixed: UI focus issues in Settings causing system bars to reappear
- Fixed: Native SIGABRT crashes during reconnection
- Cleaned up Debug settings

### v.1.12.0
- Major Improvement: Wireless Connectivity overhaul (Socket Reuse, better Handshake)
- New Feature: Wireless Mode Switch (Manual, Auto-Scan, Wireless Helper Support)
- Added: Support for Wireless Helper companion app
- Fixed: Android 15 (16KB page size) compatibility for native libraries

### v.1.11.1
- Improvement: 1440p and h265 are now checked both. Some old devices have more than 1080p but no h265 support and android auto crashes with Error 11
- Fixed bug in Kitkat Devices on search for wireless devices
- Merged PR #94 - Fixed blurry icon. Thanks to @nicoruy
- Merged PR #95 - Make Settings own View to apply directly. Thanks to @nicoruy

### v.1.11.0
- New Feature: Advanced Night Mode (Light Sensor, Screen Brightness, separate thresholds, manual time)
- Improvement: Audio Stuttering fixed (Optimized ACK handling)
- Improvement: USB Reconnection stability (Added "Reconnection Required" dialog for stuck sessions)
- Improvement: WiFi Discovery (Added Multi-Interface Scan and NSD/mDNS support)
- New Feature: Enhanced Service Notification (Reduced noise, added Exit button)
- Added: Spanish translation 🇪🇸 thanks to @andrecuellar
- Added: Ukraine translation 🇺🇦 thanks to welshi32
- Bugfix: Non-Fullscreen View was stretched, touch could be off
- Bugfix: Wifi with Headunit Server now works with hotspot

### v.1.10.4
- Added: Dutch translation 🇳🇱 thanks to safariking
- Several black screen and connection error enhancements
- Bugfix: Crash in Background if not started as foreground service

### v.1.10.3
- Bugfix: Force Software Decoder wasn't getting always the sw decoder
- Added: Russian translation 🇷🇺 thanks to @prostozema
- Enhancement: Fixing small issues in the video-decoder which should help lower spec devices to render properly (but act a little bit slower perhaps)

### v.1.10.2
- Bugfix - Button Mapping ignored #71
- New Feature: Screen-Orientation Feature to lock to a certain orientation (Landscape/Portrait) #69 thanks to @JanRi3D
- Enhancement: SSL will now attempt multiple times and not break instantly thanks to @MicaelJarniac
- Added: Chinese(Traditional) translation 🇹🇼 thanks to @GazCore
- Added: Czech translation 🇨🇿 thanks to @teodortomas #75
- Fixed brazilian portuguese folder name

### v.1.10.1
- Bugfix: Added missing 3 Byte startcode which stops some devices to start the projection
- Added PR #68 - Fix Wifi Direct detection thanks to @rakshan-kumr
- Added PR #67 - Brazilian Portuguese translation 🇧🇷 thanks to @MicaelJarniac
- Added PR #66 - Add conscrypt to fix error 7 on lower Android versions 🚀, thanks to @JanRi3D
- The old jni files and c code can maybe be removed when PR #66 is performing great. So we can get rid of that again :)

### v.1.10.0
- New Feature: Portrait Mode Support (Dashboard & Projection) with smart resolution scaling Known Bug is, that map is unresponsive to touch. That is in all HU apps
- New Feature: Redesigned Keymap Screen (easier configuration)
- New Feature: Right Hand side driving setting (#63)
- New Feature: Auto-Connect last session (Thanks to @JanRi3D) (#21)
- New Feature: Auto-Selfmode if enabled in settings
- New Feature: Allow sideloaded apps (#57)
- Localization: Added German Translation 🇩🇪 Other translations are highly appreciated
- Improvement: TextureView is now the default renderer (better compatibility for most devices)
- Improvement: Fixed Dashboard layout rotation
- Rewrite: Completly Rewrite the Video-Decoder as it was undebuggable. Removed the async mode and more

### v.1.9.0
- New Feature: GLES20 Video Renderer (Fixes black screen/artifacts/scaling on older Head Units)
- New Feature: In-App Log Export (Save to file/Share) for easier debugging
- Improvement: Audio Sink Logic fixed (System Audio always advertised) -> Fixes black screen when Audio Sink is disabled
- Improvement: Video Decoder optimized for legacy devices (Buffer size adjustments, Overflow handling)
- Hopefully Fix: Audio Stuttering resolved (Buffer/Queue logic reverted to stable state)
- Fix: Video Fragmentation on some devices (Support for split frames/Offset 2 headers)
- Fix: Crash on Android 5.1 (NoSuchMethodError)
- Fix: Audio-Sink disable not working
- UI: Consistent Dialog Theme (Teal/Rounded) and improved list buttons
- Compatibility: Verified support for Android 4.1+ (minSdk 16)
- Compatibility: Bring back native SSL Support (JNI) for better performance on older devices (Toggle in Debug Settings)

### v.1.8.1
- Fixed Fullscreen/Non-Fullscreen layout issues (black bars, overlapping)

### v.1.8.0
- Added Audio Sink Setting (Enable/Disable routing audio to HU)
- Added AAC Audio Support Setting (Experimental)
- Fixed audio stuttering issues by reverting buffering logic to v.1.4.1 defaults
- Restored robust video decoder logic (SPS Parsing) to fix black screen/crashes on Mediatek devices
- Fixed visual glitches on navigation bar and fullscreen transitions
- Improved list item UI with better click feedback
- Fixed SSL decryption crash (ArrayIndexOutOfBoundsException)

### v.1.7.0
- Added WiFi Network Discovery (Port Scan) with Auto-Connect
- Added Intent Support (`headunit://connect?ip=...`) for automation
- Added Wifi-Launcher Support with new setting
- Updated README

### v.1.6.3
- Added mandatory Safety Disclaimer on first start
- Improved audio stability and fixed stuttering issues
- Enhanced full-screen stability with transparent system bars
- Fixed WiFi disconnection synchronization issues (ByeBye request)
- General UI and stability improvements

### v.1.6.2
- Fixed critical screen flickering during startup and fullscreen transitions
- Resolved video decoder freezing issues on tablets and older devices
- Improved system bar handling for a more stable projection experience

### v.1.6.1
- Added "About" page with version info, changelog, and license
- Added "Force Legacy Decoder" (synchronous mode) setting to fix issues on some devices (e.g., Mediatek)
- Improved surface handling to prevent crashes on decoder reconfiguration
- Fixed "Unsaved changes" dialog in settings
- Updated UI with consistent back arrows and theming
- Fixed black screen issues on some devices by optimizing decoder initialization

### v.1.6.0
- Fixed the selfmode not working outside the wifi bug
- Redesign of App, Look and feel with modern Material 3
- Better Settings
- Huge Android Auto Protocol Updates
- Clicking Exit in Android Auto now closes the projection

### v.1.5.0
- Complete Rewrite of the Video decoder for better Video-Performance
- Updated Android-Auto Protocol with the latest available codecs (h265 for example)
- Added 1440p Video-Option(Note this only works with h265!)
- Added FPS-Setting
- Added Codec-Setting
- Added Force to Use Software decoder Setting
- Merged the Android Native SSL Library and get rid of the old jni files

### v.1.4.1
- Fixing Touch-Events for devices with higher resolutions
- Removing file-log and logging is only enabled if debug is on

### v.1.4.0
- Added Selfmode
- Better Close App

### v.1.3.0
- Changed the Settings Layout Look and feel
- Added DPI Option
- Added full screen option
- Fixing Keymap Changes and button recognition

### v.1.2.1 - Resolution enhancement
- Just a minor enhancement for the resolution. Not yet perfect in my opinion but better than before
- The is the last release for this year. Happy Holidays to all and a happy new year

### v.1.2.0 - Bugfix Release
- Added Exit button to app
- Added resolution settings back for better compatibility with different screen sizes
- Added Option for which texture to use. Some devices perform better on SurfaceView, some on TextureView
- Fixed keymapping
- Fixed a lot of color issues
- Fixed a bug where the app crashed on startup on some devices
- Fixed Layout on wider screens
- Some rewrite, and small bugfixes

### v1.1.0 - New Design
- Changed the basic design to a modern look and bigger buttons
- Hopefully fixed audio-stutters with audio thread and some logs
- Removed some deprecations

### v1.0.0 - Initial Revived Release
- Updated dependencies to latest versions.
- Improved compatibility with newer Android versions.
- Added Multitouch-Support
- Some sort of wireless support with Headunit-Server on Phone

## Contributing

Creating release apk needs a keystore file. You can create your own keystore file using the following command in root folder:
`keytool -genkey -v -keystore headunit-release-key.jks -alias headunit-revived -keyalg RSA -keysize 2048 -validity 10000`

After that you need to set the env variables depending on your OS:
MAC:
open ~/.zshrc or ~/.bashrc

`sudo nano ~/.zshrc or sudo nano ~/.bashrc`
`export HEADUNIT_KEYSTORE_PASSWORD="YOUR_KEYSTORE_PASSWORD"
export HEADUNIT_KEY_PASSWORD="YOUR_KEY_PASSWORD"`

## Original Headunit
Headunit for Android Auto (tm)

A new car or a $600+ headunit is NOT required to enjoy the integration and distraction reduced environment of Android Auto.

This headunit app can turn a Android 4.1+ tablet supporting USB Host mode into a basic Android Auto compatible headunit.

Android, Google Play, Google Maps, Google Play Music and Android Auto are trademarks of Google Inc.
