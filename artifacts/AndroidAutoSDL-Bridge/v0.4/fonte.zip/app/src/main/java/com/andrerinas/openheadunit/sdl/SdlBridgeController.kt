package com.andrerinas.openheadunit.sdl

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbAccessory
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Surface
import androidx.core.content.ContextCompat
import com.andrerinas.openheadunit.App
import com.andrerinas.openheadunit.aap.protocol.messages.TouchEvent as AapTouchEvent
import com.andrerinas.openheadunit.aap.protocol.proto.Input
import com.andrerinas.openheadunit.connection.CommManager
import com.andrerinas.openheadunit.utils.AppLog
import com.smartdevicelink.proxy.SdlProxyALM
import com.smartdevicelink.proxy.SdlProxyBuilder
import com.smartdevicelink.proxy.interfaces.IProxyListenerALM
import com.smartdevicelink.proxy.interfaces.OnSystemCapabilityListener
import com.smartdevicelink.proxy.rpc.DisplayCapabilities
import com.smartdevicelink.proxy.rpc.RegisterAppInterfaceResponse
import com.smartdevicelink.proxy.rpc.OnHMIStatus
import com.smartdevicelink.proxy.rpc.OnDriverDistraction
import com.smartdevicelink.proxy.rpc.OnTouchEvent
import com.smartdevicelink.proxy.rpc.enums.AppHMIType
import com.smartdevicelink.proxy.rpc.enums.HMILevel
import com.smartdevicelink.proxy.rpc.enums.DriverDistractionState
import com.smartdevicelink.proxy.rpc.enums.Language
import com.smartdevicelink.proxy.rpc.enums.SystemCapabilityType
import com.smartdevicelink.proxy.rpc.enums.TouchType
import com.smartdevicelink.transport.USBTransport
import com.smartdevicelink.transport.USBTransportConfig
import java.lang.reflect.Proxy
import java.lang.ref.WeakReference
import java.util.Vector
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.Executors

/** Process-scoped SDL client. It is deliberately independent of either Activity's lifecycle. */
class SdlBridgeController(context: Context) {
    companion object {
        // These are the exact identity values that made SDL Probe visible on the tested PLAY+.
        // The original TomTom app must be closed while this experimental identity is connected.
        private const val SDL_APP_ID = "3610601450"
        private const val SDL_APP_NAME = "TomTom"
        private const val USB_PERMISSION_SUFFIX = ".SDL_USB_PERMISSION"
    }

    private val appContext = context.applicationContext
    private val actionUsbPermission = "${appContext.packageName}$USB_PERMISSION_SUFFIX"
    private val usbManager = appContext.getSystemService(Context.USB_SERVICE) as UsbManager
    private val lock = Any()
    private val videoBusy = AtomicBoolean(false)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val videoWorker = Executors.newSingleThreadExecutor { runnable -> Thread(runnable, "SDL bridge video setup") }
    private val pendingSurfaceCallbacks = mutableListOf<(Surface?) -> Unit>()
    @Volatile private var proxy: SdlProxyALM? = null
    @Volatile private var full = false
    @Volatile private var distracted = false
    @Volatile private var armed = false
    @Volatile private var videoFailed = false
    @Volatile private var display: DisplayCapabilities? = null
    @Volatile private var requestingActivity: WeakReference<Activity>? = null
    private var output: SdlDecoderOutput? = null
    @Volatile var onVideoReadyChanged: (() -> Unit)? = null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == UsbManager.ACTION_USB_ACCESSORY_DETACHED) {
                AppLog.w("SDL bridge: USB accessory detached")
                disconnect()
                return
            }
            if (intent.action != actionUsbPermission) return

            val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
            val hasAccessoryExtra = intent.hasExtra(UsbManager.EXTRA_ACCESSORY)
            AppLog.i("SDL bridge: USB permission result granted=$granted accessoryExtra=$hasAccessoryExtra")
            if (!granted) {
                AppLog.w("SDL bridge: USB accessory permission was denied")
                return
            }

            // Some USB stacks omit EXTRA_ACCESSORY in the permission result. Mirror SDL Probe's
            // known-good flow: enumerate the accessory again and verify permission before opening.
            val accessory = usbManager.accessoryList?.firstOrNull()
            if (accessory == null) {
                AppLog.w("SDL bridge: permission granted but no AOA accessory is currently listed")
                return
            }
            if (!usbManager.hasPermission(accessory)) {
                AppLog.w("SDL bridge: permission result received but UsbManager.hasPermission is false")
                return
            }
            val activity = requestingActivity?.get()?.takeUnless {
                it.isFinishing || (Build.VERSION.SDK_INT >= 17 && it.isDestroyed)
            }
            openProxy(accessory, activity ?: appContext)
        }
    }

    init {
        ContextCompat.registerReceiver(
            appContext,
            receiver,
            IntentFilter().apply {
                addAction(actionUsbPermission)
                addAction(UsbManager.ACTION_USB_ACCESSORY_DETACHED)
            },
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    val isConnected: Boolean get() = proxy != null
    val isVideoReady: Boolean get() = armed && full && !distracted && !videoFailed && display != null && proxy != null

    /** Starts the tested AOA/SDL registration flow. Called from the user's parked-only confirmation. */
    fun connect(activity: Activity) {
        requestingActivity = WeakReference(activity)
        if (proxy != null) {
            AppLog.i("SDL bridge: already connected")
            return
        }
        val accessories = usbManager.accessoryList?.toList().orEmpty()
        AppLog.i("SDL bridge: USB check package=${appContext.packageName} accessories=${accessories.size}")
        val accessory = accessories.firstOrNull()
        if (accessory == null) {
            AppLog.w("SDL bridge: no USB accessory detected; connect the phone to PLAY+ first")
            return
        }
        AppLog.i(
            "SDL bridge: USB accessory manufacturer=${accessory.manufacturer} " +
                "model=${accessory.model} version=${accessory.version} permission=${usbManager.hasPermission(accessory)}"
        )
        if (!USBTransport.isAccessorySupported(accessory)) {
            AppLog.w("SDL bridge: SDL SDK rejected the USB accessory descriptors")
            return
        }
        if (usbManager.hasPermission(accessory)) {
            openProxy(accessory, activity)
            return
        }
        val flags = if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        val permissionIntent = Intent(actionUsbPermission).setPackage(appContext.packageName)
        try {
            usbManager.requestPermission(
                accessory,
                PendingIntent.getBroadcast(appContext, 391, permissionIntent, flags)
            )
            AppLog.i("SDL bridge: requested Android USB accessory permission action=$actionUsbPermission")
        } catch (error: Exception) {
            AppLog.e("SDL bridge: USB permission request failed", error)
        }
    }

    private fun openProxy(accessory: UsbAccessory, proxyContext: Context) {
        synchronized(lock) {
            if (proxy != null) return
            try {
                val listener = Proxy.newProxyInstance(
                    IProxyListenerALM::class.java.classLoader,
                    arrayOf(IProxyListenerALM::class.java)
                ) { self, method, args ->
                    if (method.declaringClass == Any::class.java) {
                        when (method.name) {
                            "hashCode" -> System.identityHashCode(self)
                            "equals" -> self === args?.get(0)
                            else -> "SdlBridgeListener"
                        }
                    } else {
                        val event = args?.firstOrNull()
                        if (method.name != "onOnTouchEvent") {
                            AppLog.i("SDL bridge: callback ${method.name} args=${args?.contentToString()}")
                        }
                        when (event) {
                            is RegisterAppInterfaceResponse -> {
                                AppLog.i(
                                    "SDL bridge: RAI success=${event.getSuccess()} " +
                                        "resultCode=${event.getResultCode()} info=${event.getInfo()}"
                                )
                            }
                            is OnHMIStatus -> {
                                val wasFull = full
                                full = event.hmiLevel == HMILevel.HMI_FULL
                                if (full && !wasFull) videoFailed = false
                                AppLog.i("SDL bridge: HMI=${event.hmiLevel} full=$full")
                                if (full) requestDisplay()
                                notifyVideoReadyChanged()
                            }
                            is OnDriverDistraction -> {
                                distracted = event.state == DriverDistractionState.DD_ON
                                AppLog.i("SDL bridge: driver distraction=${event.state}")
                                notifyVideoReadyChanged()
                            }
                            is OnTouchEvent -> routeTouch(event)
                        }
                        if (method.name == "onProxyClosed") {
                            full = false; armed = false; display = null; proxy = null
                            notifyVideoReadyChanged()
                            AppLog.w("SDL bridge: SDL proxy closed")
                        }
                        null
                    }
                } as IProxyListenerALM

                val types = Vector<AppHMIType>().apply { add(AppHMIType.NAVIGATION) }
                proxy = SdlProxyBuilder.Builder(listener, SDL_APP_ID, SDL_APP_NAME, false, proxyContext)
                    .setLangDesired(Language.PT_BR)
                    .setHMILangDesired(Language.PT_BR)
                    .setVrAppHMITypes(types)
                    .setTransportType(USBTransportConfig(proxyContext, accessory))
                    .setCallbackToUIThread(true)
                    .build()
                AppLog.i("SDL bridge: SDL registration started as TomTom / $SDL_APP_ID")
            } catch (error: Exception) {
                proxy = null
                AppLog.e("SDL bridge: registration failed", error)
            }
        }
    }

    private fun requestDisplay() {
        val current = proxy ?: return
        current.getCapability(SystemCapabilityType.DISPLAY, object : OnSystemCapabilityListener {
            override fun onCapabilityRetrieved(capability: Any?) {
                display = capability as? DisplayCapabilities
                val resolution = display?.screenParams?.imageResolution
                AppLog.i("SDL bridge: display=${resolution?.resolutionWidth}x${resolution?.resolutionHeight}")
                notifyVideoReadyChanged()
            }
            override fun onError(error: String?) { AppLog.w("SDL bridge: display capability failed: $error") }
        })
    }

    /** Creates the encoder off the UI thread, then returns its Surface on the main thread. */
    fun requestVideoSurface(callback: (Surface?) -> Unit) {
        if (!isVideoReady) {
            mainHandler.post { callback(null) }
            return
        }
        synchronized(lock) {
            output?.getSurface()?.let { existing ->
                mainHandler.post { callback(existing) }
                return
            }
            pendingSurfaceCallbacks.add(callback)
            if (!videoBusy.compareAndSet(false, true)) return
        }
        videoWorker.execute {
            var sink: SdlDecoderOutput? = null
            var surface: Surface? = null
            try {
                val caps = display
                val resolution = caps?.screenParams?.imageResolution
                val width = resolution?.resolutionWidth ?: 0
                val height = resolution?.resolutionHeight ?: 0
                val current = proxy
                if (isVideoReady && current != null) {
                    sink = SdlDecoderOutput(current) { message, error ->
                        AppLog.e("SDL bridge: $message", error)
                        videoFailed = true
                        notifyVideoReadyChanged()
                    }
                    surface = sink.open(width, height)
                    AppLog.i("SDL bridge: NAV H.264 surface ready ${width}x$height 30fps")
                }
            } catch (error: Exception) {
                AppLog.e("SDL bridge: could not open NAV video output", error)
            }
            val keep = synchronized(lock) {
                if (surface != null && isVideoReady && output == null) {
                    output = sink
                    true
                } else {
                    if (surface == null) videoFailed = true
                    false
                }
            }
            val callbacks = synchronized(lock) {
                pendingSurfaceCallbacks.toList().also { pendingSurfaceCallbacks.clear() }
            }
            if (!keep) {
                sink?.close()
                videoBusy.set(false)
                surface = null
            }
            val result = if (keep) surface else null
            mainHandler.post { callbacks.forEach { it(result) } }
        }
    }

    /** Must be called after VideoDecoder stopped using the returned Surface. */
    fun closeVideoOutput() {
        val previous = synchronized(lock) { output.also { output = null } }
        if (previous != null) {
            val target = previous.getSurface()
            val decoder = App.provide(appContext).videoDecoder
            if (target != null && decoder.isCurrentSurface(target)) decoder.setSurface(null)
            Thread({
                previous.close()
                videoBusy.set(false)
                AppLog.i("SDL bridge: NAV video output closed")
                val retry = synchronized(lock) {
                    pendingSurfaceCallbacks.isNotEmpty() && isVideoReady
                }
                if (retry) requestVideoSurface { }
            }, "SDL bridge video close").start()
        }
    }

    fun setArmed(value: Boolean) {
        armed = value
        if (value) videoFailed = false
        if (!value) closeVideoOutput()
        AppLog.i("SDL bridge: parked confirmation armed=$value")
        notifyVideoReadyChanged()
    }

    fun disconnect() {
        armed = false; full = false; distracted = false; display = null
        closeVideoOutput()
        val old = synchronized(lock) { proxy.also { proxy = null } }
        requestingActivity = null
        if (old != null) Thread({ try { old.dispose() } catch (error: Exception) {
            AppLog.w("SDL bridge: dispose failed", error)
        } }, "SDL bridge disconnect").start()
        notifyVideoReadyChanged()
    }

    private fun routeTouch(event: OnTouchEvent) {
        if (!isVideoReady) return
        val sdlEvent = event.event?.lastOrNull() ?: return
        val coordinate = sdlEvent.touchCoordinates?.lastOrNull() ?: return
        val caps = display ?: return
        val resolution = caps.screenParams?.imageResolution ?: return
        val width = resolution.resolutionWidth.takeIf { it > 0 } ?: return
        val height = resolution.resolutionHeight.takeIf { it > 0 } ?: return
        val targetWidth = com.andrerinas.openheadunit.utils.HeadUnitScreenConfig.getNegotiatedWidth().takeIf { it > 0 } ?: width
        val targetHeight = com.andrerinas.openheadunit.utils.HeadUnitScreenConfig.getNegotiatedHeight().takeIf { it > 0 } ?: height
        val x = ((coordinate.x ?: 0).toLong() * targetWidth / width).toInt().coerceIn(0, targetWidth - 1)
        val y = ((coordinate.y ?: 0).toLong() * targetHeight / height).toInt().coerceIn(0, targetHeight - 1)
        val action = when (event.type) {
            TouchType.BEGIN -> Input.TouchEvent.PointerAction.TOUCH_ACTION_DOWN
            TouchType.MOVE -> Input.TouchEvent.PointerAction.TOUCH_ACTION_MOVE
            TouchType.END, TouchType.CANCEL -> Input.TouchEvent.PointerAction.TOUCH_ACTION_UP
            else -> return
        }
        val manager = App.provide(appContext).commManager
        if (manager.connectionState.value !is CommManager.ConnectionState.TransportStarted) return
        manager.send(AapTouchEvent(SystemClock.elapsedRealtime(), action, 0, listOf(Triple(0, x, y))))
    }

    private fun notifyVideoReadyChanged() {
        mainHandler.post { onVideoReadyChanged?.invoke() }
    }
}
