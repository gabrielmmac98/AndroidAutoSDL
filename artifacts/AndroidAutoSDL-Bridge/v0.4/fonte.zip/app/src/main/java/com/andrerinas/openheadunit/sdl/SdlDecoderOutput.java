package com.andrerinas.openheadunit.sdl;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Process;
import android.view.Surface;
import com.smartdevicelink.proxy.SdlProxyALM;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

/** H.264 SDL NAV sink exposed as a decoder output Surface. */
final class SdlDecoderOutput implements AutoCloseable {
    interface Listener { void onFailure(String message, Throwable cause); }

    private final SdlProxyALM proxy;
    private final Listener listener;
    private final HandlerThread encoderThread = new HandlerThread("SDL AA encoder", Process.THREAD_PRIORITY_DISPLAY);
    private final AtomicBoolean started = new AtomicBoolean();
    private volatile boolean closed;
    private Handler drain;
    private Surface inputSurface;

    SdlDecoderOutput(SdlProxyALM proxy, Listener listener) {
        if (proxy == null) throw new IllegalArgumentException("SDL proxy is required");
        this.proxy = proxy;
        this.listener = listener;
    }

    /** Call after SDL registration and HMI FULL. The caller must stop the decoder before close(). */
    synchronized Surface open(int width, int height) {
        if (closed) throw new IllegalStateException("SDL video output is closed");
        if (inputSurface != null) throw new IllegalStateException("SDL video output is already open");
        if (width < 16 || height < 16 || width > 4096 || height > 4096)
            throw new IllegalArgumentException("Invalid SDL video resolution " + width + "x" + height);

        encoderThread.start();
        drain = new Handler(encoderThread.getLooper());
        CountDownLatch ready = new CountDownLatch(1);
        AtomicReference<Surface> result = new AtomicReference<>();
        AtomicReference<RuntimeException> failure = new AtomicReference<>();
        drain.post(() -> {
            try {
                inputSurface = proxy.createOpenGLInputSurface(30, 1, width, height, 1_500_000, false);
                if (inputSurface == null) throw new IllegalStateException("PLAY+ did not start the SDL NAV video service");
                proxy.startEncoder();
                started.set(true);
                result.set(inputSurface);
                drain.post(drainFrames);
            } catch (RuntimeException error) {
                failure.set(error);
                try { proxy.releaseEncoder(); proxy.endVideoStream(); } catch (Exception ignored) { }
            } finally {
                ready.countDown();
            }
        });
        try {
            if (!ready.await(12, TimeUnit.SECONDS)) throw new IllegalStateException("Timed out opening SDL video output");
        } catch (InterruptedException error) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Interrupted opening SDL video output", error);
        }
        if (failure.get() != null) throw failure.get();
        inputSurface = result.get();
        if (inputSurface == null) throw new IllegalStateException("SDL video output returned no Surface");
        return inputSurface;
    }

    private final Runnable drainFrames = new Runnable() {
        @Override public void run() {
            if (!started.get()) return;
            try {
                proxy.drainEncoder(false);
                Handler handler = drain;
                if (started.get() && handler != null) handler.postDelayed(this, 5);
            } catch (RuntimeException error) {
                started.set(false);
                if (listener != null) listener.onFailure("SDL H.264 drain failed", error);
            }
        }
    };

    synchronized Surface getSurface() { return inputSurface; }

    /** Only after the Android Auto decoder has stopped rendering to this Surface. */
    @Override public synchronized void close() {
        if (closed) return;
        closed = true;
        started.set(false);
        Handler handler = drain;
        if (handler != null) handler.removeCallbacksAndMessages(null);
        if (encoderThread.isAlive() && handler != null && Looper.myLooper() != encoderThread.getLooper()) {
            CountDownLatch stopped = new CountDownLatch(1);
            handler.post(() -> {
                try { proxy.drainEncoder(true); } catch (RuntimeException ignored) { }
                try { proxy.releaseEncoder(); } catch (Exception ignored) { }
                try { proxy.endVideoStream(); } catch (Exception ignored) { }
                stopped.countDown();
            });
            try { stopped.await(1500, TimeUnit.MILLISECONDS); }
            catch (InterruptedException error) { Thread.currentThread().interrupt(); }
            encoderThread.quitSafely();
            try { encoderThread.join(1500); }
            catch (InterruptedException error) { Thread.currentThread().interrupt(); }
        } else {
            try { proxy.releaseEncoder(); } catch (Exception ignored) { }
            try { proxy.endVideoStream(); } catch (Exception ignored) { }
        }
        // SdlProxyALM owns the input Surface together with its encoder; releaseEncoder tears both down.
        inputSurface = null;
    }
}
