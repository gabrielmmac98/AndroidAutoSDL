package br.local.sdlprobe;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Uncompressed Windows BMP, 24-bit BGR, padded bottom-up rows. */
final class Bmp24 {
    static byte[] encode(int width,int height,int[] argb) {
        if(width<1||height<1||width>1024||height>1024||argb.length!=width*height)
            throw new IllegalArgumentException("Invalid BMP dimensions/pixels");
        int stride=(width*3+3)&~3;
        ByteBuffer out=ByteBuffer.allocate(54+stride*height).order(ByteOrder.LITTLE_ENDIAN);
        out.put((byte)'B').put((byte)'M').putInt(out.capacity()).putInt(0).putInt(54);
        out.putInt(40).putInt(width).putInt(height).putShort((short)1).putShort((short)24);
        out.putInt(0).putInt(stride*height).putInt(2835).putInt(2835).putInt(0).putInt(0);
        for(int y=height-1;y>=0;y--) {
            for(int x=0;x<width;x++) {
                int color=argb[y*width+x];
                out.put((byte)color).put((byte)(color>>>8)).put((byte)(color>>>16));
            }
            for(int pad=width*3;pad<stride;pad++)out.put((byte)0);
        }
        return out.array();
    }
}
