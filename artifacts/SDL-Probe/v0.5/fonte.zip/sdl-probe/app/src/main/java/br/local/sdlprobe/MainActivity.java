package br.local.sdlprobe;

import android.app.*;
import android.os.*;
import android.content.*;
import android.hardware.usb.*;
import android.view.*;
import android.widget.*;
import android.graphics.*;
import com.smartdevicelink.proxy.*;
import com.smartdevicelink.proxy.interfaces.*;
import com.smartdevicelink.proxy.rpc.*;
import com.smartdevicelink.proxy.rpc.enums.*;
import com.smartdevicelink.transport.*;
import java.lang.reflect.Proxy;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    // Experimental identifier; NOT an approved SDL application ID.
    private static final String APP_ID = "8274106392";
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final StringBuilder journal = new StringBuilder();
    private TextView status;
    private CheckBox parked;
    private CheckBox ordinaryMode;
    private CheckBox compatibilityMode;
    private boolean ordinarySession;
    private boolean showSent;
    private volatile String sdkTrace="";
    private SdlProxyALM proxy;
    private volatile boolean full, distracted, running, closed;
    private final java.util.concurrent.atomic.AtomicBoolean videoBusy = new java.util.concurrent.atomic.AtomicBoolean();
    private volatile int touchX = -1, touchY = -1;
    private volatile DisplayCapabilities display;
    private boolean serviceListenerAdded;
    private boolean iconRequested;
    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        public void onReceive(Context c, Intent i) {
            if (UsbManager.ACTION_USB_ACCESSORY_DETACHED.equals(i.getAction())) { disconnect(); return; }
            if ("br.local.sdlprobe.USB_PERMISSION".equals(i.getAction())) {
                if (i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) connect();
                else log("USB permission denied");
            }
        }
    };
    public void onCreate(Bundle b) {
        super.onCreate(b);
        com.smartdevicelink.util.DebugTool.enableDebugTool();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        LinearLayout box = new LinearLayout(this); box.setOrientation(1); box.setPadding(24,24,24,24);
        TextView title = new TextView(this); title.setText("SDL Probe 0.5\nTeste independente — carro estacionado\nIdentidade experimental ou compatibilidade TomTom"); box.addView(title);
        compatibilityMode=new CheckBox(this);compatibilityMode.setText("Teste de identidade: TomTom / 3610601450 (encerre o TomTom original)");compatibilityMode.setChecked(true);box.addView(compatibilityMode);
        ordinaryMode=new CheckBox(this); ordinaryMode.setText("Controle de listagem: aplicativo comum (DEFAULT, sem vídeo)"); ordinaryMode.setChecked(false);ordinaryMode.setEnabled(false);box.addView(ordinaryMode);
        compatibilityMode.setOnCheckedChangeListener((v,checked)-> {
            if(checked)ordinaryMode.setChecked(false);
            ordinaryMode.setEnabled(!checked && proxy==null);
        });
        parked = new CheckBox(this); parked.setText("Carro estacionado e freio de estacionamento acionado"); box.addView(parked);
        parked.setOnCheckedChangeListener((v, yes) -> { if (!yes) running = false; });
        button(box,"1. Conectar USB", () -> connect());
        button(box,"2. Testar vídeo e toque", () -> startVideo());
        button(box,"Parar / desconectar", () -> disconnect());
        button(box,"Registrar estado atual", () -> snapshot());
        button(box,"Exportar diagnóstico", () -> {
            snapshot();
            new Thread(()-> {
                sdkTrace=collectSdkTrace();
                runOnUiThread(()-> {
                    if(closed)return;
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("text/plain").addCategory(Intent.CATEGORY_OPENABLE);
                    i.putExtra(Intent.EXTRA_TITLE,"sdl-probe-diagnostico.txt"); startActivityForResult(i,20);
                });
            },"Probe export logs").start();
        });
        status = new TextView(this); status.setTextIsSelectable(true);
        ScrollView scroll = new ScrollView(this); scroll.addView(status); box.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(box);
        IntentFilter f = new IntentFilter("br.local.sdlprobe.USB_PERMISSION"); f.addAction(UsbManager.ACTION_USB_ACCESSORY_DETACHED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED); else registerReceiver(receiver,f);
        log("Probe=0.5 Android="+Build.VERSION.RELEASE+" SDK="+Build.VERSION.SDK_INT+" SDL SDK=4.12.2; no AA receiver; no audio");
        log("Abra este app, conecte o cabo e toque Conectar. Depois selecione SDL Probe na central.");
    }
    private void button(LinearLayout box,String label,Runnable r) { Button b=new Button(this); b.setText(label); b.setOnClickListener(v->r.run()); box.addView(b); }
    private synchronized void log(String s) {
        journal.append(new Date()).append(" ").append(s).append('\n');
        android.util.Log.i("SDLProbe",s);
        if (status!=null && !closed) runOnUiThread(()-> { synchronized(this) { int n=journal.length(); status.setText(journal.substring(Math.max(0,n-14000))); } });
        try(FileOutputStream out=openFileOutput("session.txt",MODE_APPEND)) { out.write((s+"\n").getBytes("UTF-8")); } catch(Exception ignored){}
    }
    private void connect() {
        if(proxy!=null) { log("Já existe uma sessão; desconecte antes de repetir."); return; }
        UsbManager usb=(UsbManager)getSystemService(USB_SERVICE);
        UsbAccessory[] accessories=usb.getAccessoryList();
        if(accessories==null || accessories.length==0) { log("Nenhum acessório AOA detectado."); return; }
        UsbAccessory a=accessories[0];
        log("USB manufacturer="+a.getManufacturer()+" model="+a.getModel()+" version="+a.getVersion());
        if(!USBTransport.isAccessorySupported(a)) { log("SDK recusou os descritores do acessório."); return; }
        if(!usb.hasPermission(a)) {
            int flags=Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0;
            usb.requestPermission(a,PendingIntent.getBroadcast(this,0,new Intent("br.local.sdlprobe.USB_PERMISSION").setPackage(getPackageName()),flags)); return;
        }
        try {
            IProxyListenerALM listener=(IProxyListenerALM)Proxy.newProxyInstance(IProxyListenerALM.class.getClassLoader(),new Class[]{IProxyListenerALM.class},(obj,m,args)-> {
                if(m.getDeclaringClass()==Object.class) {
                    if(m.getName().equals("hashCode")) return System.identityHashCode(obj);
                    if(m.getName().equals("equals")) return obj==args[0];
                    return "SDLProbeListener";
                }
                String name=m.getName(); log(name+" "+RpcLog.describe(args));
                if(args!=null && args.length>0) {
                    if(args[0] instanceof OnHMIStatus) {
                        full=((OnHMIStatus)args[0]).getHmiLevel()==HMILevel.HMI_FULL;
                        log("HMI level="+((OnHMIStatus)args[0]).getHmiLevel()+" full="+full);
                        if(full && ordinarySession && proxy!=null && !showSent) {
                            showSent=true;
                            Show show=new Show();show.setMainField1("SDL Probe: conexão confirmada");show.setMainField2("Controle DEFAULT — sem vídeo");
                            show.setOnRPCResponseListener(new com.smartdevicelink.proxy.rpc.listeners.OnRPCResponseListener(){
                                public void onResponse(int id,RPCResponse answer){log("CONTROL Show="+RpcLog.describe(answer));}
                            });
                            try {proxy.sendRPCRequest(show);}catch(Exception error){log("CONTROL Show ERROR "+error);}
                        }
                        if(!full) running=false;
                        if(proxy!=null) {
                            if(!serviceListenerAdded) {
                                ISdlServiceListener services=(ISdlServiceListener)Proxy.newProxyInstance(ISdlServiceListener.class.getClassLoader(),new Class[]{ISdlServiceListener.class},(o,method,values)-> {
                                    if(method.getDeclaringClass()==Object.class) {
                                        if(method.getName().equals("hashCode"))return System.identityHashCode(o);
                                        if(method.getName().equals("equals"))return o==values[0];
                                        return "SDLProbeServices";
                                    }
                                    log("SERVICE "+method.getName()+" "+RpcLog.describe(values)); return null;
                                });
                                proxy.addServiceListener(com.smartdevicelink.protocol.enums.SessionType.NAV,services);
                                serviceListenerAdded=true;
                            }
                            snapshot();
                            proxy.getCapability(SystemCapabilityType.DISPLAY,new OnSystemCapabilityListener(){
                                public void onCapabilityRetrieved(Object o){ display=(DisplayCapabilities)o; log("DISPLAY="+RpcLog.describe(o)); uploadIcon(); }
                                public void onError(String error){ log("DISPLAY ERROR="+error); }
                            });
                        }
                    }
                    if(args[0] instanceof OnDriverDistraction) {
                        distracted=((OnDriverDistraction)args[0]).getState()==DriverDistractionState.DD_ON;
                        if(distracted) running=false;
                    }
                    if(args[0] instanceof OnTouchEvent) {
                        OnTouchEvent t=(OnTouchEvent)args[0];
                        if(t.getEvent()!=null && !t.getEvent().isEmpty() && !t.getEvent().get(0).getTouchCoordinates().isEmpty()) {
                            TouchCoord xy=t.getEvent().get(0).getTouchCoordinates().get(0); touchX=xy.getX(); touchY=xy.getY();
                        }
                    }
                }
                if(name.equals("onProxyClosed")) { full=false; running=false; }
                return null;
            });
            boolean compatibility=compatibilityMode.isChecked();
            String sessionId=compatibility?"3610601450":APP_ID;
            String sessionName=compatibility?"TomTom":"SDL Probe";
            ordinarySession=!compatibility && ordinaryMode.isChecked();ordinaryMode.setEnabled(false);compatibilityMode.setEnabled(false);
            Vector<AppHMIType> types=new Vector<>(); types.add(ordinarySession?AppHMIType.DEFAULT:AppHMIType.NAVIGATION);
            log("REGISTER requested language=PT-BR hmiDisplayLanguage=PT-BR appId="+sessionId+" appName="+sessionName+" type="+types+" compatibilityIdentity="+compatibility);
            proxy=new SdlProxyBuilder.Builder(listener,sessionId,sessionName,false,this).setLangDesired(Language.PT_BR).setHMILangDesired(Language.PT_BR).setVrAppHMITypes(types).setTransportType(new USBTransportConfig(this,a)).setCallbackToUIThread(true).build();
            log("Registro solicitado. Procure "+sessionName+" com ícone azul SDL na central. O protótipo não é o TomTom original.");
        }catch(Exception e){log("CONNECT ERROR "+e);}
    }
    private void startVideo() {
        if(ordinarySession){log("Modo DEFAULT: teste de listagem apenas, sem vídeo. Para NAVIGATION, desconecte e desmarque o controle antes de conectar novamente.");return;}
        if(!parked.isChecked() || !full || distracted || proxy==null || display==null) { snapshot(); log("Vídeo bloqueado: parked="+parked.isChecked()+" full="+full+" distracted="+distracted+" proxy="+(proxy!=null)+" display="+(display!=null)); return; }
        if(videoBusy.get()) { log("Aguarde o encerramento do vídeo anterior."); return; }
        final SdlProxyALM p=proxy;
        final int w=display.getScreenParams().getImageResolution().getResolutionWidth();
        final int h=display.getScreenParams().getImageResolution().getResolutionHeight();
        if(w<16||h<16||w>4096||h>4096) {log("Resolução inválida: "+w+"x"+h);return;}
        if(!videoBusy.compareAndSet(false,true))return;
        running=true;
        worker.execute(()-> {
            PatternRenderer renderer=null;
            try {
                log("Solicitando NAV não criptografado "+w+"x"+h+" 30fps 1500000bps");
                Surface s=p.createOpenGLInputSurface(30,1,w,h,1500000,false);
                if(s==null) { log("NAV sem Surface: falha de negociação/ACK, capacidade ou encoder. Consulte logcat SDL.");return; }
                renderer=new PatternRenderer(s,w,h); p.startEncoder();
                log("Surface criada; quadros sintéticos iniciados. Confirme visualmente na central.");
                int frame=0;
                while(running && full && !distracted && !closed) {
                    renderer.draw(frame++,touchX,touchY); p.drainEncoder(false); Thread.sleep(33);
                }
            }catch(Exception e){log("VIDEO ERROR "+e);}
            finally {
                running=false;
                if(renderer!=null) renderer.close();
                try {p.releaseEncoder(); p.endVideoStream();}catch(Exception e){log("STOP "+e);}
                log("Vídeo parado.");
                videoBusy.set(false);
            }
        });
    }
    private void disconnect() {
        running=false; full=false; display=null; serviceListenerAdded=false; iconRequested=false; showSent=false;
        if(compatibilityMode!=null)compatibilityMode.setEnabled(true);
        if(ordinaryMode!=null)ordinaryMode.setEnabled(compatibilityMode==null || !compatibilityMode.isChecked());
        final SdlProxyALM old=proxy; proxy=null;
        if(old!=null)worker.execute(()->{try{old.dispose();}catch(Exception e){log("DISPOSE "+e);}});
        log("Desconexão solicitada.");
    }
    private void snapshot() {
        log("STATE full="+full+" distracted="+distracted+" running="+running+" display="+(display!=null));
        SdlProxyALM p=proxy;
        if(p!=null) {
            try {
                log("CONNECTION="+p.getConnectionDetails());
                RegisterAppInterfaceResponse rai=p.getRegisterAppInterfaceResponse();
                log("RAI="+RpcLog.describe(rai));
                if(rai!=null)log("RAI success="+rai.getSuccess()+" resultCode="+rai.getResultCode()+" info="+rai.getInfo());
            }catch(Exception e){log("SNAPSHOT ERROR "+e);}
        }
    }
    private void uploadIcon() {
        if(iconRequested || proxy==null || display==null)return;
        iconRequested=true;
        final SdlProxyALM p=proxy;
        try {
            int w=64,h=64;
            FileType type=FileType.GRAPHIC_PNG;
            if(display.getImageFields()!=null)for(ImageField f:display.getImageFields()) {
                if(f.getName()!=ImageFieldName.appIcon)continue;
                if(f.getImageResolution()!=null) {w=f.getImageResolution().getResolutionWidth(); h=f.getImageResolution().getResolutionHeight();}
                if(f.getImageTypeSupported()!=null && !f.getImageTypeSupported().contains(type)) {
                    if(f.getImageTypeSupported().contains(FileType.GRAPHIC_JPEG)) type=FileType.GRAPHIC_JPEG;
                    else if(f.getImageTypeSupported().contains(FileType.GRAPHIC_BMP)) type=FileType.GRAPHIC_BMP;
                    else {log("ICON: central não anunciou PNG/JPEG/BMP para appIcon");return;}
                }
            }
            if(w<1||h<1||w>1024||h>1024){log("ICON: dimensões inválidas "+w+"x"+h);return;}
            Bitmap bitmap=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
            Canvas canvas=new Canvas(bitmap);canvas.drawColor(Color.rgb(20,90,170));
            Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);paint.setColor(Color.WHITE);paint.setTextSize(Math.min(w,h)*0.38f);paint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("SDL",w/2f,h*0.64f,paint);
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();
            if(type==FileType.GRAPHIC_BMP) {
                int[] pixels=new int[w*h];bitmap.getPixels(pixels,0,w,0,0,w,h);
                bytes.write(Bmp24.encode(w,h,pixels));
            } else bitmap.compress(type==FileType.GRAPHIC_PNG?Bitmap.CompressFormat.PNG:Bitmap.CompressFormat.JPEG,95,bytes);
            bitmap.recycle();
            final String filename=type==FileType.GRAPHIC_BMP?"probe-icon.bmp":type==FileType.GRAPHIC_PNG?"probe-icon.png":"probe-icon.jpg";
            PutFile file=new PutFile();file.setSdlFileName(filename);file.setFileType(type);file.setFileData(bytes.toByteArray());
            file.setOnRPCResponseListener(new com.smartdevicelink.proxy.rpc.listeners.OnPutFileUpdateListener(){
                public void onResponse(int id,RPCResponse response,long total){
                    log("ICON PutFile="+RpcLog.describe(response));
                    if(!Boolean.TRUE.equals(response.getSuccess()))return;
                    SetAppIcon icon=new SetAppIcon();icon.setSdlFileName(filename);
                    icon.setOnRPCResponseListener(new com.smartdevicelink.proxy.rpc.listeners.OnRPCResponseListener(){
                        public void onResponse(int correlation,RPCResponse answer){log("ICON SetAppIcon="+RpcLog.describe(answer));}
                    });
                    try{p.sendRPCRequest(icon);}catch(Exception e){log("ICON SetAppIcon ERROR "+e);}
                }
            });
            log("ICON upload "+w+"x"+h+" type="+type); p.sendRPCRequest(file);
        }catch(Exception e){log("ICON ERROR "+e);}
    }
    protected void onStop(){running=false; super.onStop();}
    protected void onDestroy(){closed=true; disconnect(); unregisterReceiver(receiver); worker.shutdown(); super.onDestroy();}
    private String collectSdkTrace() {
        java.lang.Process process=null;StringBuilder text=new StringBuilder("\n--- SDK LOGCAT: processo do SDL Probe apenas ---\n");
        try {
            process=new ProcessBuilder("logcat","-d","-v","time","--pid="+android.os.Process.myPid(),"-t","1500").redirectErrorStream(true).start();
            try(BufferedReader input=new BufferedReader(new InputStreamReader(process.getInputStream(),"UTF-8"))) {
                String line;
                while((line=input.readLine())!=null && text.length()<250000) {
                    if(!line.contains("SDLProbe")) text.append(line).append('\n');
                }
            }
        }catch(Exception error){text.append("SDK LOGCAT ERROR ").append(error);}
        finally{if(process!=null)process.destroy();}
        return text.toString();
    }
    protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==20 && result==RESULT_OK && data!=null) {
            try(OutputStream out=getContentResolver().openOutputStream(data.getData())) { synchronized(this){out.write(journal.toString().getBytes("UTF-8"));} out.write(sdkTrace.getBytes("UTF-8")); log("Diagnóstico exportado."); }
            catch(Exception e){log("EXPORT ERROR "+e);}
        }
    }
}
