package br.local.sdlprobe;

import com.smartdevicelink.proxy.RPCStruct;
import java.lang.reflect.Array;

final class RpcLog {
    static String describe(Object value) {
        if(value==null)return "null";
        if(value instanceof RPCStruct) {
            try { return ((RPCStruct)value).serializeJSON().toString(); }
            catch(Exception error) { return "SERIALIZATION_ERROR "+value.getClass().getName()+": "+error; }
        }
        if(value.getClass().isArray()) {
            StringBuilder text=new StringBuilder("[");
            for(int i=0;i<Array.getLength(value);i++) { if(i>0)text.append(", "); text.append(describe(Array.get(value,i))); }
            return text.append(']').toString();
        }
        return String.valueOf(value);
    }
}
