package br.local.sdlprobe;

import org.junit.Test;
import static org.junit.Assert.*;
import org.json.JSONObject;
import com.smartdevicelink.proxy.rpc.*;
import com.smartdevicelink.proxy.rpc.enums.*;

public class RpcLogTest {
    @Test public void registrationResponseContainsRealFields() throws Exception {
        RegisterAppInterfaceResponse response=new RegisterAppInterfaceResponse();
        response.setSuccess(true);response.setResultCode(Result.SUCCESS);response.setInfo("diagnostic-marker");
        String text=RpcLog.describe(response);
        assertTrue(text,text.contains("diagnostic-marker"));
        assertTrue(text,text.contains("success"));
        assertTrue(text,text.contains("SUCCESS"));
        new JSONObject(text);
    }
    @Test public void callbackArrayContainsHmiLevelInsteadOfObjectAddress() {
        OnHMIStatus hmi=new OnHMIStatus();hmi.setHmiLevel(HMILevel.HMI_NONE);
        String text=RpcLog.describe(new Object[]{hmi});
        assertTrue(text,text.contains("hmiLevel"));
        assertTrue(text,text.contains("NONE"));
        assertFalse(text,text.contains("OnHMIStatus@"));
    }
}
