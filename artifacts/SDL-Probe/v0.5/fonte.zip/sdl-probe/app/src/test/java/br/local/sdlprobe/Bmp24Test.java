package br.local.sdlprobe;

import org.junit.Test;
import static org.junit.Assert.*;
import java.nio.*;
import java.io.*;

public class Bmp24Test {
    @Test public void oddWidthRoundTripsColorsAndOrientation() throws Exception {
        int[] pixels={0xffff0000,0xff00ff00,0xff0000ff,0xff123456,0xffabcdef,0xff654321};
        byte[] bmp=Bmp24.encode(3,2,pixels);
        assertEquals(54+12*2,bmp.length);
        ByteBuffer header=ByteBuffer.wrap(bmp).order(ByteOrder.LITTLE_ENDIAN);
        assertEquals(54,header.getInt(10));assertEquals(24,header.getShort(28));assertEquals(0,header.getInt(30));
        Object decoded=decode(bmp);
        assertEquals(3,dimension(decoded,"getWidth"));assertEquals(2,dimension(decoded,"getHeight"));
        int[] restored=(int[])decoded.getClass().getMethod("getRGB",int.class,int.class,int.class,int.class,int[].class,int.class,int.class).invoke(decoded,0,0,3,2,null,0,3);
        assertArrayEquals(pixels,restored);
    }
    @Test public void announcedIconSizesDecode() throws Exception {
        for(int size:new int[]{35,70}) {
            int[] pixels=new int[size*size];java.util.Arrays.fill(pixels,0xff145aaa);
            Object decoded=decode(Bmp24.encode(size,size,pixels));
            assertEquals(size,dimension(decoded,"getWidth"));assertEquals(size,dimension(decoded,"getHeight"));
            assertEquals(0xff145aaa,((Integer)decoded.getClass().getMethod("getRGB",int.class,int.class).invoke(decoded,size-1,size-1)).intValue());
        }
    }
    // Desktop ImageIO provides an independent decoder in the host test JVM.
    private Object decode(byte[] bmp) throws Exception {
        return Class.forName("javax.imageio.ImageIO").getMethod("read",InputStream.class).invoke(null,new ByteArrayInputStream(bmp));
    }
    private int dimension(Object decoded,String method) throws Exception {
        return ((Integer)decoded.getClass().getMethod(method).invoke(decoded)).intValue();
    }
}
