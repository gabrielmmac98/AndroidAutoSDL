# SDL Probe 0.5

Protótipo de diagnóstico para Toyota PLAY+. Aplicativo separado do TomTom, sem receptor Android Auto. Leia SDL-Probe-0.5-instrucoes.md antes do teste: esta versão registra por padrão nome TomTom e App ID público 3610601450 para comparação de identidade. Encerre o TomTom original antes de conectar. Na central, procure TomTom com ícone azul SDL.

Desmarcar o teste de identidade retorna ao App ID experimental 8274106392/nome SDL Probe. O controle DEFAULT serve para listagem sem vídeo; NAVIGATION permite tentar vídeo após ativação normal FULL. Troca de modo exige desconexão. Não modifica TomTom/firmware/políticas. A central pode guardar ícone por ID.

## Compilar

JDK compatível com Android Gradle Plugin 9.4.1, Gradle 9.6.0 e Android SDK plataforma 37. Configure ANDROID_HOME ou local.properties com sdk.dir. Execute gradle testDebugUnitTest assembleDebug. Saída app/build/outputs/apk/debug/app-debug.apk. SDK público com.smartdevicelink:sdl_android:4.12.2 via Maven Central; versão declarada igual à extraída do TomTom, sem garantia de ausência de personalização pelo fabricante.

## Funcionalidades e limites

USB direto/AOA SDL-Core-1.0, registro PT-BR, ícone BMP/PNG/JPEG conforme capacidades, diagnóstico JSON com resultado das RPCs, exportação manual com logcat do próprio processo. Vídeo sintético via EGL/MediaCodec H.264 30fps/1,5Mbit/s em NAVIGATION e dimensões anunciadas pela central. Cruz preta indica última coordenada bruta recebida. Sem áudio, microfone ou integração Android Auto.

Este APK de depuração não tem serviço persistente. Mantenha o app aberto; vídeo para ao perder visibilidade ou FULL, receber distração ON, desmarcar estacionamento ou desconectar. Não mede fisicamente freio/velocidade. Os registros permanecem locais; exportação pode incluir identificadores enviados pela central/telefone.

## Histórico de evidências

0.1: transporte respondia, mas log usava referências de objetos. 0.2: JSON revelou WRONG_LANGUAGE e ícones BMP. 0.3: idioma, registro, PutFile e SetAppIcon SUCCESS; HMI NONE, app ausente. 0.4: DEFAULT igualmente aceito e ausente; sessão aberta por mais de 40 segundos. 0.5 compara identificação conhecida com NAVIGATION experimental, sem pressupor desbloqueio.

Quatro testes automatizados verificam JSON e BMP, incluindo leitura independente das imagens 35/70. Comunicação e vídeo com a PLAY+ precisam de validação pelo usuário.
