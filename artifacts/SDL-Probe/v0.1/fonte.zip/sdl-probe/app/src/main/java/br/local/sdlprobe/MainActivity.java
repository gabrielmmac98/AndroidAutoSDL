package br.local.sdlprobe;

import android.app.*;
import android.os.*;
import android.content.*;
import android.hardware.usb.*;
import android.view.*;
import android.widget.*;
import android.graphics.*;
import com.smartdevicelink.proxy.*;
import com.smartdevicelink.proxy.interfaces.*;
import com.smartdevicelink.proxy.rpc.*;
import com.smartdevicelink.proxy.rpc.enums.*;
import com.smartdevicelink.transport.*;
import java.lang.reflect.Proxy;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    // Experimental identifier; NOT an approved SDL application ID.
    private static final String APP_ID = "8274106392";
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final StringBuilder journal = new StringBuilder();
    private TextView status;
    private CheckBox parked;
    private SdlProxyALM proxy;
    private volatile boolean full, distracted, running, closed;
    private final java.util.concurrent.atomic.AtomicBoolean videoBusy = new java.util.concurrent.atomic.AtomicBoolean();
    private volatile int touchX = -1, touchY = -1;
    private volatile DisplayCapabilities display;
    private boolean serviceListenerAdded;
    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        public void onReceive(Context c, Intent i) {
            if (UsbManager.ACTION_USB_ACCESSORY_DETACHED.equals(i.getAction())) { disconnect(); return; }
            if ("br.local.sdlprobe.USB_PERMISSION".equals(i.getAction())) {
                if (i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) connect();
                else log("USB permission denied");
            }
        }
    };
    public void onCreate(Bundle b) {
        super.onCreate(b);
        com.smartdevicelink.util.DebugTool.enableDebugTool();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        LinearLayout box = new LinearLayout(this); box.setOrientation(1); box.setPadding(24,24,24,24);
        TextView title = new TextView(this); title.setText("SDL Probe 0.1\nTeste independente — carro estacionado\nID experimental: " + APP_ID); box.addView(title);
        parked = new CheckBox(this); parked.setText("Carro estacionado e freio de estacionamento acionado"); box.addView(parked);
        parked.setOnCheckedChangeListener((v, yes) -> { if (!yes) running = false; });
        button(box,"1. Conectar USB", () -> connect());
        button(box,"2. Testar vídeo e toque", () -> startVideo());
        button(box,"Parar / desconectar", () -> disconnect());
        button(box,"Exportar diagnóstico", () -> {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("text/plain").addCategory(Intent.CATEGORY_OPENABLE);
            i.putExtra(Intent.EXTRA_TITLE,"sdl-probe-diagnostico.txt"); startActivityForResult(i,20);
        });
        status = new TextView(this); status.setTextIsSelectable(true);
        ScrollView scroll = new ScrollView(this); scroll.addView(status); box.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(box);
        IntentFilter f = new IntentFilter("br.local.sdlprobe.USB_PERMISSION"); f.addAction(UsbManager.ACTION_USB_ACCESSORY_DETACHED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED); else registerReceiver(receiver,f);
        log("Android="+Build.VERSION.RELEASE+" SDK="+Build.VERSION.SDK_INT+" SDL SDK=4.12.2; no AA receiver; no audio");
        log("Abra este app, conecte o cabo e toque Conectar. Depois selecione SDL Probe na central.");
    }
    private void button(LinearLayout box,String label,Runnable r) { Button b=new Button(this); b.setText(label); b.setOnClickListener(v->r.run()); box.addView(b); }
    private synchronized void log(String s) {
        journal.append(new Date()).append(" ").append(s).append('\n');
        android.util.Log.i("SDLProbe",s);
        if (status!=null && !closed) runOnUiThread(()-> { synchronized(this) { int n=journal.length(); status.setText(journal.substring(Math.max(0,n-14000))); } });
        try(FileOutputStream out=openFileOutput("session.txt",MODE_APPEND)) { out.write((s+"\n").getBytes("UTF-8")); } catch(Exception ignored){}
    }
    private void connect() {
        if(proxy!=null) { log("Já existe uma sessão; desconecte antes de repetir."); return; }
        UsbManager usb=(UsbManager)getSystemService(USB_SERVICE);
        UsbAccessory[] accessories=usb.getAccessoryList();
        if(accessories==null || accessories.length==0) { log("Nenhum acessório AOA detectado."); return; }
        UsbAccessory a=accessories[0];
        log("USB manufacturer="+a.getManufacturer()+" model="+a.getModel()+" version="+a.getVersion());
        if(!USBTransport.isAccessorySupported(a)) { log("SDK recusou os descritores do acessório."); return; }
        if(!usb.hasPermission(a)) {
            int flags=Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0;
            usb.requestPermission(a,PendingIntent.getBroadcast(this,0,new Intent("br.local.sdlprobe.USB_PERMISSION").setPackage(getPackageName()),flags)); return;
        }
        try {
            IProxyListenerALM listener=(IProxyListenerALM)Proxy.newProxyInstance(IProxyListenerALM.class.getClassLoader(),new Class[]{IProxyListenerALM.class},(obj,m,args)-> {
                if(m.getDeclaringClass()==Object.class) {
                    if(m.getName().equals("hashCode")) return System.identityHashCode(obj);
                    if(m.getName().equals("equals")) return obj==args[0];
                    return "SDLProbeListener";
                }
                String name=m.getName(); log(name+" "+Arrays.toString(args));
                if(args!=null && args.length>0) {
                    if(args[0] instanceof OnHMIStatus) {
                        full=((OnHMIStatus)args[0]).getHmiLevel()==HMILevel.HMI_FULL;
                        if(!full) running=false;
                        if(proxy!=null) {
                            if(!serviceListenerAdded) {
                                ISdlServiceListener services=(ISdlServiceListener)Proxy.newProxyInstance(ISdlServiceListener.class.getClassLoader(),new Class[]{ISdlServiceListener.class},(o,method,values)-> {
                                    if(method.getDeclaringClass()==Object.class) {
                                        if(method.getName().equals("hashCode"))return System.identityHashCode(o);
                                        if(method.getName().equals("equals"))return o==values[0];
                                        return "SDLProbeServices";
                                    }
                                    log("SERVICE "+method.getName()+" "+Arrays.toString(values)); return null;
                                });
                                proxy.addServiceListener(com.smartdevicelink.protocol.enums.SessionType.NAV,services);
                                serviceListenerAdded=true;
                            }
                            log("RAI="+proxy.getRegisterAppInterfaceResponse());
                            proxy.getCapability(SystemCapabilityType.DISPLAY,new OnSystemCapabilityListener(){
                                public void onCapabilityRetrieved(Object o){ display=(DisplayCapabilities)o; log("DISPLAY="+o); }
                                public void onError(String error){ log("DISPLAY ERROR="+error); }
                            });
                        }
                    }
                    if(args[0] instanceof OnDriverDistraction) {
                        distracted=((OnDriverDistraction)args[0]).getState()==DriverDistractionState.DD_ON;
                        if(distracted) running=false;
                    }
                    if(args[0] instanceof OnTouchEvent) {
                        OnTouchEvent t=(OnTouchEvent)args[0];
                        if(t.getEvent()!=null && !t.getEvent().isEmpty() && !t.getEvent().get(0).getTouchCoordinates().isEmpty()) {
                            TouchCoord xy=t.getEvent().get(0).getTouchCoordinates().get(0); touchX=xy.getX(); touchY=xy.getY();
                        }
                    }
                }
                if(name.equals("onProxyClosed")) { full=false; running=false; }
                return null;
            });
            Vector<AppHMIType> types=new Vector<>(); types.add(AppHMIType.NAVIGATION);
            proxy=new SdlProxyBuilder.Builder(listener,APP_ID,"SDL Probe",false,this).setVrAppHMITypes(types).setTransportType(new USBTransportConfig(this,a)).setCallbackToUIThread(true).build();
            log("Registro solicitado com ID experimental; aguarde HMI FULL ao selecionar o aplicativo na central.");
        }catch(Exception e){log("CONNECT ERROR "+e);}
    }
    private void startVideo() {
        if(!parked.isChecked() || !full || distracted || proxy==null || display==null) { log("Vídeo exige confirmação de estacionamento, HMI FULL, capacidade de tela e ausência de distração ON."); return; }
        if(videoBusy.get()) { log("Aguarde o encerramento do vídeo anterior."); return; }
        final SdlProxyALM p=proxy;
        final int w=display.getScreenParams().getImageResolution().getResolutionWidth();
        final int h=display.getScreenParams().getImageResolution().getResolutionHeight();
        if(w<16||h<16||w>4096||h>4096) {log("Resolução inválida: "+w+"x"+h);return;}
        if(!videoBusy.compareAndSet(false,true))return;
        running=true;
        worker.execute(()-> {
            PatternRenderer renderer=null;
            try {
                log("Solicitando NAV não criptografado "+w+"x"+h+" 30fps 1500000bps");
                Surface s=p.createOpenGLInputSurface(30,1,w,h,1500000,false);
                if(s==null) { log("NAV sem Surface: falha de negociação/ACK, capacidade ou encoder. Consulte logcat SDL.");return; }
                renderer=new PatternRenderer(s,w,h); p.startEncoder();
                log("Surface criada; quadros sintéticos iniciados. Confirme visualmente na central.");
                int frame=0;
                while(running && full && !distracted && !closed) {
                    renderer.draw(frame++,touchX,touchY); p.drainEncoder(false); Thread.sleep(33);
                }
            }catch(Exception e){log("VIDEO ERROR "+e);}
            finally {
                running=false;
                if(renderer!=null) renderer.close();
                try {p.releaseEncoder(); p.endVideoStream();}catch(Exception e){log("STOP "+e);}
                log("Vídeo parado.");
                videoBusy.set(false);
            }
        });
    }
    private void disconnect() {
        running=false; full=false; display=null; serviceListenerAdded=false;
        final SdlProxyALM old=proxy; proxy=null;
        if(old!=null)worker.execute(()->{try{old.dispose();}catch(Exception e){log("DISPOSE "+e);}});
        log("Desconexão solicitada.");
    }
    protected void onStop(){running=false; super.onStop();}
    protected void onDestroy(){closed=true; disconnect(); unregisterReceiver(receiver); worker.shutdown(); super.onDestroy();}
    protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==20 && result==RESULT_OK && data!=null) {
            try(OutputStream out=getContentResolver().openOutputStream(data.getData())) { synchronized(this){out.write(journal.toString().getBytes("UTF-8"));} log("Diagnóstico exportado."); }
            catch(Exception e){log("EXPORT ERROR "+e);}
        }
    }
}
