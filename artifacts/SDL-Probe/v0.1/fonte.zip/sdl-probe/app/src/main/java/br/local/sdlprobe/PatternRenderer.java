package br.local.sdlprobe;

import android.opengl.*;
import android.view.Surface;

final class PatternRenderer implements AutoCloseable {
    private final EGLDisplay display;
    private final EGLContext context;
    private final EGLSurface window;
    private final int width,height;
    PatternRenderer(Surface surface,int w,int h) {
        width=w;height=h;
        display=EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
        if(!EGL14.eglInitialize(display,new int[2],0,new int[2],1))throw new IllegalStateException("EGL init");
        EGLConfig[] configs=new EGLConfig[1]; int[] count=new int[1];
        int[] attributes={EGL14.EGL_RED_SIZE,8,EGL14.EGL_GREEN_SIZE,8,EGL14.EGL_BLUE_SIZE,8,EGL14.EGL_RENDERABLE_TYPE,EGL14.EGL_OPENGL_ES2_BIT,0x3142,1,EGL14.EGL_NONE};
        EGL14.eglChooseConfig(display,attributes,0,configs,0,1,count,0);
        if(count[0]==0)throw new IllegalStateException("EGL config");
        context=EGL14.eglCreateContext(display,configs[0],EGL14.EGL_NO_CONTEXT,new int[]{EGL14.EGL_CONTEXT_CLIENT_VERSION,2,EGL14.EGL_NONE},0);
        window=EGL14.eglCreateWindowSurface(display,configs[0],surface,new int[]{EGL14.EGL_NONE},0);
        if(!EGL14.eglMakeCurrent(display,window,window,context))throw new IllegalStateException("EGL current");
    }
    private void rect(int x,int y,int w,int h,float r,float g,float b){
        GLES20.glScissor(x,height-y-h,w,h);GLES20.glClearColor(r,g,b,1);GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
    }
    void draw(int frame,int x,int y) {
        GLES20.glEnable(GLES20.GL_SCISSOR_TEST);
        float[][] colors={{1,0,0},{0,1,0},{0,0,1},{1,1,0},{0,1,1},{1,0,1}};
        for(int i=0;i<6;i++)rect(i*width/6,0,(i+1)*width/6-i*width/6,height,colors[i][0],colors[i][1],colors[i][2]);
        // White targets at 10%, 50%, 90%; moving square confirms fresh video.
        for(int a=1;a<=9;a+=4)for(int b=1;b<=9;b+=4){int xx=width*a/10, yy=height*b/10;rect(xx-15,yy-2,30,4,1,1,1);rect(xx-2,yy-15,4,30,1,1,1);}
        rect(frame%Math.max(1,width-24),height-28,24,24,1,1,1);
        if(x>=0 && y>=0){rect(Math.max(0,x-18),Math.max(0,y-3),36,6,0,0,0);rect(Math.max(0,x-3),Math.max(0,y-18),6,36,0,0,0);}
        EGLExt.eglPresentationTimeANDROID(display,window,System.nanoTime());
        if(!EGL14.eglSwapBuffers(display,window))throw new IllegalStateException("EGL swap");
    }
    public void close(){EGL14.eglMakeCurrent(display,EGL14.EGL_NO_SURFACE,EGL14.EGL_NO_SURFACE,EGL14.EGL_NO_CONTEXT);EGL14.eglDestroySurface(display,window);EGL14.eglDestroyContext(display,context);EGL14.eglTerminate(display);}
}
