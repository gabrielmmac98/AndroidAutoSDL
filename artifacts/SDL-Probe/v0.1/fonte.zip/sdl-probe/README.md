# SDL Probe 0.1 — Toyota PLAY+

Protótipo separado do TomTom para testar registro SDL, vídeo sintético e coordenadas de toque. Não implementa Android Auto. Não modifica o TomTom nem a central.

## Uso no carro

1. Com o carro estacionado e freio de estacionamento acionado, instale `SDL-Probe-0.1.apk` no telefone. O Android pode informar que o aplicativo foi criado para uma versão antiga; o target 28 foi escolhido para este ensaio com SDK legado. Abertura básica verificada em emulador Android 17/API 37.
2. Feche o TomTom. Se ele abrir automaticamente ao conectar USB, limpe apenas a associação de abertura USB dele nas configurações de aplicativos do telefone. Não precisa desinstalá-lo.
3. Abra **SDL Probe**, mantenha o aplicativo visível e conecte o telefone à PLAY+ pelo cabo que funciona com o TomTom. Escolha SDL Probe e conceda acesso ao acessório USB quando solicitado.
4. Toque **1. Conectar USB**. O aplicativo mostrará manufacturer/model/version e os callbacks do SDK.
5. Procure **SDL Probe** na lista de aplicativos da central e selecione-o. Aguarde o registro de HMI FULL e DISPLAY no diagnóstico.
6. Marque a confirmação de estacionamento e toque **2. Testar vídeo e toque** no telefone. A transmissão depende de registro e autorização aceitos pela central.
7. Se aparecerem barras coloridas, confirme se o quadrado branco inferior se move. Toque nas nove cruzes brancas, uma de cada vez. Uma marca preta indica a última coordenada recebida. Anote se o erro cresce da esquerda para a direita ou de cima para baixo, se é fixo e se há inversão vertical.
8. Toque **Parar / desconectar** antes de retirar o cabo. Use **Exportar diagnóstico** para salvar o texto e anexá-lo à conversa, junto de uma foto da tela da central se houver imagem.

Mantenha o app aberto: este primeiro protótipo não possui serviço persistente. A transmissão para quando a atividade deixa de ficar visível, perde HMI FULL, recebe distração ON, a confirmação de estacionamento é desmarcada ou a sessão é encerrada. Exportar diagnóstico também pode parar o vídeo ao abrir o seletor de arquivos. A confirmação manual não mede velocidade ou freio do carro.

## Como interpretar

- Sem acessório AOA: primeiro verificar cabo, associação USB e SDL ativado na central.
- Descritores recusados: o SDK 4.12.2 exige SDL/Core/1.0. O filtro XML deste protótipo omite a versão para que a seleção inicial não esconda essa diferença. O diagnóstico informa o valor real.
- Registro recusado ou ícone ausente: exportar os callbacks e motivos de fechamento. O ID `8274106392` é experimental, não foi cadastrado/aprovado e não é apresentado como identidade TomTom. Rejeição desse ID não estabelece por si só se há exigência de cadastro, política de fabricante ou outra incompatibilidade.
- HMI FULL sem DISPLAY: exportar o erro de capacidades.
- Surface nula / serviço recusado: conferir eventos `SERVICE`, erros e parâmetros rejeitados no log do SDK. O protótipo não altera políticas nem tenta contornar recusas.
- Barras visíveis e quadrado em movimento: sucesso de vídeo para este aplicativo; testar toque em seguida.
- Toque deslocado: conservar coordenadas e foto para calcular escala/offset. Não aplicar a correção observada no TomTom cegamente à ponte.

Envie o diagnóstico mesmo que não apareça ícone ou vídeo. Ele é o resultado necessário para escolher a próxima etapa. Não suponha sucesso pelo simples fato de a conexão USB ser aceita.

## Implementação e limites

SDK público `com.smartdevicelink:sdl_android:4.12.2`, disponível no Maven Central conforme a [documentação oficial](https://smartdevicelink.com/en/guides/android/getting-started/installation/). A correspondência de versão com o APK não garante que o SDK TomTom não tenha alterações próprias.

Registro NAVIGATION, isMediaApplication=false, transporte USB direto. Vídeo via Surface EGL/OpenGL → MediaCodec → serviço NAV não criptografado, 30 fps, 1,5 Mbit/s, I-frame a cada segundo. Dimensões retiradas de DisplayCapabilities. Coordenadas brutas de toque são marcadas sem transformação para expor erros de escala. Sem áudio, microfone, localização, coleta de dados do veículo ou receptor AA. A primeira versão registra callbacks usando interfaces dinâmicas; os caminhos USB/SDL e o renderer ainda precisam de validação com hardware real.

O APK é de depuração, assinado com chave de desenvolvimento, e pode ser removido normalmente. O SDK legado inclui dependências antigas. O protótipo não solicita acesso à internet. Os registros permanecem locais e são exportados manualmente; revise-os antes de compartilhar, pois respostas da central podem conter identificadores do equipamento/telefone. O arquivo exportado contém a sessão atual; o aplicativo também mantém `files/session.txt` em sua área privada.

## Compilar

Requisitos: JDK compatível com Android Gradle Plugin 9.4.1, Gradle 9.6.0, Android SDK plataforma 37 e repositórios Google/Maven Central. Configure ANDROID_HOME ou local.properties com sdk.dir. Execute `gradle assembleDebug` na raiz. Saída: `app/build/outputs/apk/debug/app-debug.apk`.

## Validação realizada

- Compilação assembleDebug concluída.
- Assinaturas v1/v2 verificadas com apksigner.
- Instalação e abertura em emulador Android 17/API 37 concluídas, com mensagens iniciais no log e sem erro AndroidRuntime no período observado.
- Nenhum telefone físico conectado ao computador na verificação.
- USB com a PLAY+, autorização, renderização no carro e toque: ainda não testados.

Fonte do experimento: análise estática do APK original e confirmação do usuário de que a interface TomTom e os toques funcionam na PLAY+, embora haja deslocamento de toque. Essa confirmação é observação do usuário, não uma captura de protocolo realizada aqui.
